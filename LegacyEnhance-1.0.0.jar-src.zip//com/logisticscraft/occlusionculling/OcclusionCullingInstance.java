package com.logisticscraft.occlusionculling;

import com.logisticscraft.occlusionculling.cache.ArrayOcclusionCache;
import com.logisticscraft.occlusionculling.cache.OcclusionCache;
import com.logisticscraft.occlusionculling.util.MathUtilities;
import com.logisticscraft.occlusionculling.util.Vec3d;
import java.util.Arrays;
import java.util.BitSet;

public class OcclusionCullingInstance {
   private static final int ON_MIN_X = 1;
   private static final int ON_MAX_X = 2;
   private static final int ON_MIN_Y = 4;
   private static final int ON_MAX_Y = 8;
   private static final int ON_MIN_Z = 16;
   private static final int ON_MAX_Z = 32;
   private final int reach;
   private final double aabbExpansion;
   private final DataProvider provider;
   private final OcclusionCache cache;
   private final BitSet skipList;
   private final Vec3d[] targetPoints;
   private final Vec3d targetPos;
   private final int[] cameraPos;
   private final boolean[] dotselectors;
   private boolean allowRayChecks;
   private final int[] lastHitBlock;

   public OcclusionCullingInstance(int maxDistance, DataProvider provider) {
      this(maxDistance, provider, new ArrayOcclusionCache(maxDistance), 0.5D);
   }

   public OcclusionCullingInstance(int maxDistance, DataProvider provider, OcclusionCache cache, double aabbExpansion) {
      this.skipList = new BitSet();
      this.targetPoints = new Vec3d[15];
      this.targetPos = new Vec3d(0.0D, 0.0D, 0.0D);
      this.cameraPos = new int[3];
      this.dotselectors = new boolean[14];
      this.allowRayChecks = false;
      this.lastHitBlock = new int[3];
      this.reach = maxDistance;
      this.provider = provider;
      this.cache = cache;
      this.aabbExpansion = aabbExpansion;

      for(int i = 0; i < this.targetPoints.length; ++i) {
         this.targetPoints[i] = new Vec3d(0.0D, 0.0D, 0.0D);
      }

   }

   public boolean isAABBVisible(Vec3d aabbMin, Vec3d aabbMax, Vec3d viewerPosition) {
      try {
         int maxX = MathUtilities.floor(aabbMax.x + this.aabbExpansion);
         int maxY = MathUtilities.floor(aabbMax.y + this.aabbExpansion);
         int maxZ = MathUtilities.floor(aabbMax.z + this.aabbExpansion);
         int minX = MathUtilities.floor(aabbMin.x - this.aabbExpansion);
         int minY = MathUtilities.floor(aabbMin.y - this.aabbExpansion);
         int minZ = MathUtilities.floor(aabbMin.z - this.aabbExpansion);
         this.cameraPos[0] = MathUtilities.floor(viewerPosition.x);
         this.cameraPos[1] = MathUtilities.floor(viewerPosition.y);
         this.cameraPos[2] = MathUtilities.floor(viewerPosition.z);
         OcclusionCullingInstance.Relative relX = OcclusionCullingInstance.Relative.from(minX, maxX, this.cameraPos[0]);
         OcclusionCullingInstance.Relative relY = OcclusionCullingInstance.Relative.from(minY, maxY, this.cameraPos[1]);
         OcclusionCullingInstance.Relative relZ = OcclusionCullingInstance.Relative.from(minZ, maxZ, this.cameraPos[2]);
         if (relX == OcclusionCullingInstance.Relative.INSIDE && relY == OcclusionCullingInstance.Relative.INSIDE && relZ == OcclusionCullingInstance.Relative.INSIDE) {
            return true;
         } else {
            this.skipList.clear();
            int id = 0;

            int x;
            int y;
            for(x = minX; x <= maxX; ++x) {
               for(int y = minY; y <= maxY; ++y) {
                  for(int z = minZ; z <= maxZ; ++z) {
                     y = this.getCacheValue(x, y, z);
                     if (y == 1) {
                        return true;
                     }

                     if (y != 0) {
                        this.skipList.set(id);
                     }

                     ++id;
                  }
               }
            }

            this.allowRayChecks = false;
            id = 0;

            for(x = minX; x <= maxX; ++x) {
               byte visibleOnFaceX = 0;
               byte faceEdgeDataX = 0;
               byte faceEdgeDataX = (byte)(faceEdgeDataX | (x == minX ? 1 : 0));
               faceEdgeDataX = (byte)(faceEdgeDataX | (x == maxX ? 2 : 0));
               byte visibleOnFaceX = (byte)(visibleOnFaceX | (x == minX && relX == OcclusionCullingInstance.Relative.POSITIVE ? 1 : 0));
               visibleOnFaceX = (byte)(visibleOnFaceX | (x == maxX && relX == OcclusionCullingInstance.Relative.NEGATIVE ? 2 : 0));

               for(y = minY; y <= maxY; ++y) {
                  byte faceEdgeDataY = (byte)(faceEdgeDataX | (y == minY ? 4 : 0));
                  faceEdgeDataY = (byte)(faceEdgeDataY | (y == maxY ? 8 : 0));
                  byte visibleOnFaceY = (byte)(visibleOnFaceX | (y == minY && relY == OcclusionCullingInstance.Relative.POSITIVE ? 4 : 0));
                  visibleOnFaceY = (byte)(visibleOnFaceY | (y == maxY && relY == OcclusionCullingInstance.Relative.NEGATIVE ? 8 : 0));

                  for(int z = minZ; z <= maxZ; ++z) {
                     byte faceEdgeData = (byte)(faceEdgeDataY | (z == minZ ? 16 : 0));
                     faceEdgeData = (byte)(faceEdgeData | (z == maxZ ? 32 : 0));
                     byte visibleOnFace = (byte)(visibleOnFaceY | (z == minZ && relZ == OcclusionCullingInstance.Relative.POSITIVE ? 16 : 0));
                     visibleOnFace = (byte)(visibleOnFace | (z == maxZ && relZ == OcclusionCullingInstance.Relative.NEGATIVE ? 32 : 0));
                     if (this.skipList.get(id)) {
                        ++id;
                     } else {
                        if (visibleOnFace != 0) {
                           this.targetPos.set((double)x, (double)y, (double)z);
                           if (this.isVoxelVisible(viewerPosition, this.targetPos, faceEdgeData, visibleOnFace)) {
                              return true;
                           }
                        }

                        ++id;
                     }
                  }
               }
            }

            return false;
         }
      } catch (Throwable var23) {
         var23.printStackTrace();
         return true;
      }
   }

   private boolean isVoxelVisible(Vec3d viewerPosition, Vec3d position, byte faceData, byte visibleOnFace) {
      int targetSize = 0;
      Arrays.fill(this.dotselectors, false);
      if ((visibleOnFace & 1) == 1) {
         this.dotselectors[0] = true;
         if ((faceData & -2) != 0) {
            this.dotselectors[1] = true;
            this.dotselectors[4] = true;
            this.dotselectors[5] = true;
         }

         this.dotselectors[8] = true;
      }

      if ((visibleOnFace & 4) == 4) {
         this.dotselectors[0] = true;
         if ((faceData & -5) != 0) {
            this.dotselectors[3] = true;
            this.dotselectors[4] = true;
            this.dotselectors[7] = true;
         }

         this.dotselectors[9] = true;
      }

      if ((visibleOnFace & 16) == 16) {
         this.dotselectors[0] = true;
         if ((faceData & -17) != 0) {
            this.dotselectors[1] = true;
            this.dotselectors[4] = true;
            this.dotselectors[5] = true;
         }

         this.dotselectors[10] = true;
      }

      if ((visibleOnFace & 2) == 2) {
         this.dotselectors[4] = true;
         if ((faceData & -3) != 0) {
            this.dotselectors[5] = true;
            this.dotselectors[6] = true;
            this.dotselectors[7] = true;
         }

         this.dotselectors[11] = true;
      }

      if ((visibleOnFace & 8) == 8) {
         this.dotselectors[1] = true;
         if ((faceData & -9) != 0) {
            this.dotselectors[2] = true;
            this.dotselectors[5] = true;
            this.dotselectors[6] = true;
         }

         this.dotselectors[12] = true;
      }

      if ((visibleOnFace & 32) == 32) {
         this.dotselectors[2] = true;
         if ((faceData & -33) != 0) {
            this.dotselectors[3] = true;
            this.dotselectors[6] = true;
            this.dotselectors[7] = true;
         }

         this.dotselectors[13] = true;
      }

      if (this.dotselectors[0]) {
         this.targetPoints[targetSize++].setAdd(position, 0.05D, 0.05D, 0.05D);
      }

      if (this.dotselectors[1]) {
         this.targetPoints[targetSize++].setAdd(position, 0.05D, 0.95D, 0.05D);
      }

      if (this.dotselectors[2]) {
         this.targetPoints[targetSize++].setAdd(position, 0.05D, 0.95D, 0.95D);
      }

      if (this.dotselectors[3]) {
         this.targetPoints[targetSize++].setAdd(position, 0.05D, 0.05D, 0.95D);
      }

      if (this.dotselectors[4]) {
         this.targetPoints[targetSize++].setAdd(position, 0.95D, 0.05D, 0.05D);
      }

      if (this.dotselectors[5]) {
         this.targetPoints[targetSize++].setAdd(position, 0.95D, 0.95D, 0.05D);
      }

      if (this.dotselectors[6]) {
         this.targetPoints[targetSize++].setAdd(position, 0.95D, 0.95D, 0.95D);
      }

      if (this.dotselectors[7]) {
         this.targetPoints[targetSize++].setAdd(position, 0.95D, 0.05D, 0.95D);
      }

      if (this.dotselectors[8]) {
         this.targetPoints[targetSize++].setAdd(position, 0.05D, 0.5D, 0.5D);
      }

      if (this.dotselectors[9]) {
         this.targetPoints[targetSize++].setAdd(position, 0.5D, 0.05D, 0.5D);
      }

      if (this.dotselectors[10]) {
         this.targetPoints[targetSize++].setAdd(position, 0.5D, 0.5D, 0.05D);
      }

      if (this.dotselectors[11]) {
         this.targetPoints[targetSize++].setAdd(position, 0.95D, 0.5D, 0.5D);
      }

      if (this.dotselectors[12]) {
         this.targetPoints[targetSize++].setAdd(position, 0.5D, 0.95D, 0.5D);
      }

      if (this.dotselectors[13]) {
         this.targetPoints[targetSize++].setAdd(position, 0.5D, 0.5D, 0.95D);
      }

      return this.isVisible(viewerPosition, this.targetPoints, targetSize);
   }

   private boolean rayIntersection(int[] b, Vec3d rayOrigin, Vec3d rayDir) {
      Vec3d rInv = (new Vec3d(1.0D, 1.0D, 1.0D)).div(rayDir);
      double t1 = ((double)b[0] - rayOrigin.x) * rInv.x;
      double t2 = ((double)(b[0] + 1) - rayOrigin.x) * rInv.x;
      double t3 = ((double)b[1] - rayOrigin.y) * rInv.y;
      double t4 = ((double)(b[1] + 1) - rayOrigin.y) * rInv.y;
      double t5 = ((double)b[2] - rayOrigin.z) * rInv.z;
      double t6 = ((double)(b[2] + 1) - rayOrigin.z) * rInv.z;
      double tmin = Math.max(Math.max(Math.min(t1, t2), Math.min(t3, t4)), Math.min(t5, t6));
      double tmax = Math.min(Math.min(Math.max(t1, t2), Math.max(t3, t4)), Math.max(t5, t6));
      if (tmax > 0.0D) {
         return false;
      } else {
         return !(tmin > tmax);
      }
   }

   private boolean isVisible(Vec3d start, Vec3d[] targets, int size) {
      int x = this.cameraPos[0];
      int y = this.cameraPos[1];
      int z = this.cameraPos[2];

      for(int v = 0; v < size; ++v) {
         Vec3d target = targets[v];
         double relativeX = start.x - target.getX();
         double relativeY = start.y - target.getY();
         double relativeZ = start.z - target.getZ();
         if (!this.allowRayChecks || !this.rayIntersection(this.lastHitBlock, start, (new Vec3d(relativeX, relativeY, relativeZ)).normalize())) {
            double dimensionX = Math.abs(relativeX);
            double dimensionY = Math.abs(relativeY);
            double dimensionZ = Math.abs(relativeZ);
            double dimFracX = 1.0D / dimensionX;
            double dimFracY = 1.0D / dimensionY;
            double dimFracZ = 1.0D / dimensionZ;
            int intersectCount = 1;
            byte x_inc;
            double t_next_x;
            if (dimensionX == 0.0D) {
               x_inc = 0;
               t_next_x = dimFracX;
            } else if (target.x > start.x) {
               x_inc = 1;
               intersectCount += MathUtilities.floor(target.x) - x;
               t_next_x = (double)((float)(((double)(x + 1) - start.x) * dimFracX));
            } else {
               x_inc = -1;
               intersectCount += x - MathUtilities.floor(target.x);
               t_next_x = (double)((float)((start.x - (double)x) * dimFracX));
            }

            byte y_inc;
            double t_next_y;
            if (dimensionY == 0.0D) {
               y_inc = 0;
               t_next_y = dimFracY;
            } else if (target.y > start.y) {
               y_inc = 1;
               intersectCount += MathUtilities.floor(target.y) - y;
               t_next_y = (double)((float)(((double)(y + 1) - start.y) * dimFracY));
            } else {
               y_inc = -1;
               intersectCount += y - MathUtilities.floor(target.y);
               t_next_y = (double)((float)((start.y - (double)y) * dimFracY));
            }

            byte z_inc;
            double t_next_z;
            if (dimensionZ == 0.0D) {
               z_inc = 0;
               t_next_z = dimFracZ;
            } else if (target.z > start.z) {
               z_inc = 1;
               intersectCount += MathUtilities.floor(target.z) - z;
               t_next_z = (double)((float)(((double)(z + 1) - start.z) * dimFracZ));
            } else {
               z_inc = -1;
               intersectCount += z - MathUtilities.floor(target.z);
               t_next_z = (double)((float)((start.z - (double)z) * dimFracZ));
            }

            boolean finished = this.stepRay(start, x, y, z, dimFracX, dimFracY, dimFracZ, intersectCount, x_inc, y_inc, z_inc, t_next_y, t_next_x, t_next_z);
            this.provider.cleanup();
            if (finished) {
               this.cacheResult(targets[0], true);
               return true;
            }

            this.allowRayChecks = true;
         }
      }

      this.cacheResult(targets[0], false);
      return false;
   }

   private boolean stepRay(Vec3d start, int currentX, int currentY, int currentZ, double distInX, double distInY, double distInZ, int n, int x_inc, int y_inc, int z_inc, double t_next_y, double t_next_x, double t_next_z) {
      for(; n > 1; --n) {
         int cVal = this.getCacheValue(currentX, currentY, currentZ);
         if (cVal == 2) {
            this.lastHitBlock[0] = currentX;
            this.lastHitBlock[1] = currentY;
            this.lastHitBlock[2] = currentZ;
            return false;
         }

         if (cVal == 0) {
            int chunkX = currentX >> 4;
            int chunkZ = currentZ >> 4;
            if (!this.provider.prepareChunk(chunkX, chunkZ)) {
               return false;
            }

            if (this.provider.isOpaqueFullCube(currentX, currentY, currentZ)) {
               this.cache.setLastHidden();
               this.lastHitBlock[0] = currentX;
               this.lastHitBlock[1] = currentY;
               this.lastHitBlock[2] = currentZ;
               return false;
            }

            this.cache.setLastVisible();
         }

         if (t_next_y < t_next_x && t_next_y < t_next_z) {
            currentY += y_inc;
            t_next_y += distInY;
         } else if (t_next_x < t_next_y && t_next_x < t_next_z) {
            currentX += x_inc;
            t_next_x += distInX;
         } else {
            currentZ += z_inc;
            t_next_z += distInZ;
         }
      }

      return true;
   }

   private int getCacheValue(int x, int y, int z) {
      x -= this.cameraPos[0];
      y -= this.cameraPos[1];
      z -= this.cameraPos[2];
      return Math.abs(x) <= this.reach - 2 && Math.abs(y) <= this.reach - 2 && Math.abs(z) <= this.reach - 2 ? this.cache.getState(x + this.reach, y + this.reach, z + this.reach) : -1;
   }

   private void cacheResult(int x, int y, int z, boolean result) {
      int cx = x - this.cameraPos[0] + this.reach;
      int cy = y - this.cameraPos[1] + this.reach;
      int cz = z - this.cameraPos[2] + this.reach;
      if (result) {
         this.cache.setVisible(cx, cy, cz);
      } else {
         this.cache.setHidden(cx, cy, cz);
      }

   }

   private void cacheResult(Vec3d vector, boolean result) {
      int cx = MathUtilities.floor(vector.x) - this.cameraPos[0] + this.reach;
      int cy = MathUtilities.floor(vector.y) - this.cameraPos[1] + this.reach;
      int cz = MathUtilities.floor(vector.z) - this.cameraPos[2] + this.reach;
      if (result) {
         this.cache.setVisible(cx, cy, cz);
      } else {
         this.cache.setHidden(cx, cy, cz);
      }

   }

   public void resetCache() {
      this.cache.resetCache();
   }

   private static enum Relative {
      INSIDE,
      POSITIVE,
      NEGATIVE;

      public static OcclusionCullingInstance.Relative from(int min, int max, int pos) {
         if (max > pos && min > pos) {
            return POSITIVE;
         } else {
            return min < pos && max < pos ? NEGATIVE : INSIDE;
         }
      }
   }
}
