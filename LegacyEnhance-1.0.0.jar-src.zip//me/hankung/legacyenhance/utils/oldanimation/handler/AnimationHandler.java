package me.hankung.legacyenhance.utils.oldanimation.handler;

import me.hankung.legacyenhance.LegacyEnhance;
import me.hankung.legacyenhance.mixin.oldanimation.FoodItemAccessor;
import net.minecraft.class_1037;
import net.minecraft.class_1065;
import net.minecraft.class_1069;
import net.minecraft.class_1071;
import net.minecraft.class_1099;
import net.minecraft.class_1600;
import net.minecraft.class_1734;
import net.minecraft.class_2403;
import net.minecraft.class_2552;
import net.minecraft.class_328;
import net.minecraft.class_518;
import net.minecraft.class_529;
import net.minecraft.class_629;
import net.minecraft.class_837;
import net.minecraft.class_860;
import net.minecraft.class_234.class_235;
import net.minecraft.class_2462.class_2464;

public class AnimationHandler {
   private final class_1600 mc = class_1600.method_2965();
   public float prevSwingProgress;
   public float swingProgress;
   private int swingProgressInt;
   private boolean isSwingInProgress;

   public float getSwingProgress(float partialTickTime) {
      float currentProgress = this.swingProgress - this.prevSwingProgress;
      if (!this.isSwingInProgress) {
         return this.mc.field_10310.method_6148(partialTickTime);
      } else {
         if (currentProgress < 0.0F) {
            ++currentProgress;
         }

         return this.prevSwingProgress + currentProgress * partialTickTime;
      }
   }

   private int getArmSwingAnimationEnd(class_518 player) {
      return player.method_6107(class_860.field_3168) ? 5 - player.method_6131(class_860.field_3168).method_2455() : (player.method_6107(class_860.field_3169) ? 8 + player.method_6131(class_860.field_3169).method_2455() * 2 : 6);
   }

   private void updateSwingProgress() {
      class_518 player = this.mc.field_10310;
      if (player != null) {
         this.prevSwingProgress = this.swingProgress;
         int max = this.getArmSwingAnimationEnd(player);
         if (LegacyEnhance.CONFIG.oldanimatePunching.get() && this.mc.field_3823.field_940.method_6619() && this.mc.field_3822 != null && this.mc.field_3822.field_595 == class_235.field_7609 && (!this.isSwingInProgress || this.swingProgressInt >= max >> 1 || this.swingProgressInt < 0)) {
            this.isSwingInProgress = true;
            this.swingProgressInt = -1;
         }

         if (this.isSwingInProgress) {
            ++this.swingProgressInt;
            if (this.swingProgressInt >= max) {
               this.swingProgressInt = 0;
               this.isSwingInProgress = false;
            }
         } else {
            this.swingProgressInt = 0;
         }

         this.swingProgress = (float)this.swingProgressInt / (float)max;
      }

   }

   public void onTick() {
      this.updateSwingProgress();
   }

   public boolean renderItemInFirstPerson(class_529 renderer, class_1071 stack, float equipProgress, float partialTicks) {
      if (stack == null) {
         return false;
      } else {
         class_1069 item = stack.method_3421();
         if (item != class_1734.field_7026 && !this.mc.method_9391().method_10240(stack)) {
            class_1099 action = stack.method_3444();
            if ((item != class_1734.field_7014 || LegacyEnhance.CONFIG.oldanimateOldRod.get()) && (action != class_1099.field_9156 || LegacyEnhance.CONFIG.oldanimateOldModel.get()) && (action != class_1099.field_9159 || LegacyEnhance.CONFIG.oldanimateOldSwordBlock.get()) && (action != class_1099.field_9160 || LegacyEnhance.CONFIG.oldanimateOldBow.get())) {
               class_518 player = this.mc.field_10310;
               float var4 = player.field_3195 + (player.field_3193 - player.field_3195) * partialTicks;
               class_2403.method_9791();
               class_2403.method_9817(var4, 1.0F, 0.0F, 0.0F);
               class_2403.method_9817(player.field_3194 + (player.field_3258 - player.field_3194) * partialTicks, 0.0F, 1.0F, 0.0F);
               class_328.method_846();
               class_2403.method_9792();
               float pitch = player.field_1768 + (player.field_1766 - player.field_1768) * partialTicks;
               float yaw = player.field_1767 + (player.field_1765 - player.field_1767) * partialTicks;
               class_2403.method_9817((player.field_3193 - pitch) * 0.1F, 1.0F, 0.0F, 0.0F);
               class_2403.method_9817((player.field_3258 - yaw) * 0.1F, 0.0F, 1.0F, 0.0F);
               class_2403.method_9788();
               if (item instanceof class_1037) {
                  class_2403.method_9843();
                  class_2403.method_9805(770, 771, 1, 0);
               }

               int i = this.mc.field_3803.method_8578(new class_2552(player.field_3252, player.field_3253 + (double)player.method_2544(), player.field_3254), 0);
               float brightnessX = (float)(i & '\uffff');
               float brightnessY = (float)(i >> 16);
               class_629.method_1763(class_629.field_2301, brightnessX, brightnessY);
               int rgb = item.method_3344(stack, 0);
               float red = (float)(rgb >> 16 & 255) / 255.0F;
               float green = (float)(rgb >> 8 & 255) / 255.0F;
               float blue = (float)(rgb & 255) / 255.0F;
               class_2403.method_9825(red, green, blue, 1.0F);
               class_2403.method_9791();
               int useCount = player.method_3192();
               float swingProgress = this.getSwingProgress(partialTicks);
               boolean blockHitOverride = false;
               if (LegacyEnhance.CONFIG.oldanimatePunching.get() && useCount <= 0 && this.mc.field_3823.field_941.method_6619()) {
                  boolean block = action == class_1099.field_9159;
                  boolean consume = false;
                  if (item instanceof class_1065) {
                     boolean alwaysEdible = ((FoodItemAccessor)item).getAlwaysEdible();
                     if (player.method_3205(alwaysEdible)) {
                        consume = action == class_1099.field_9157 || action == class_1099.field_9158;
                     }
                  }

                  if (block || consume) {
                     blockHitOverride = true;
                  }
               }

               if ((useCount > 0 || blockHitOverride) && action != class_1099.field_9156 && this.mc.field_10310.method_3193()) {
                  switch(action) {
                  case field_9157:
                  case field_9158:
                     this.doConsumeAnimation(stack, useCount, partialTicks);
                     this.doEquipAndSwingTransform(equipProgress, LegacyEnhance.CONFIG.oldanimateOldBlockHit.get() ? swingProgress : 0.0F);
                     break;
                  case field_9159:
                     this.doEquipAndSwingTransform(equipProgress, LegacyEnhance.CONFIG.oldanimateOldBlockHit.get() ? swingProgress : 0.0F);
                     this.doSwordBlockAnimation();
                     break;
                  case field_9160:
                     this.doEquipAndSwingTransform(equipProgress, LegacyEnhance.CONFIG.oldanimateOldBlockHit.get() ? swingProgress : 0.0F);
                     this.doBowAnimation(stack, useCount, partialTicks);
                  }
               } else {
                  this.doSwingTranslation(swingProgress);
                  this.doEquipAndSwingTransform(equipProgress, swingProgress);
               }

               if (item.method_3390()) {
                  class_2403.method_9817(180.0F, 0.0F, 1.0F, 0.0F);
               }

               if (this.doFirstPersonTransform(stack)) {
                  renderer.method_9872(player, stack, class_2464.field_10994);
               } else {
                  renderer.method_9872(player, stack, class_2464.field_10992);
               }

               class_2403.method_9792();
               if (item instanceof class_1037) {
                  class_2403.method_9842();
               }

               class_2403.method_9789();
               class_328.method_843();
               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public void doSwordBlock3rdPersonTransform() {
      if (LegacyEnhance.CONFIG.oldanimateOldSwordBlock3rd.get()) {
         class_2403.method_9816(-0.15F, -0.2F, 0.0F);
         class_2403.method_9817(70.0F, 1.0F, 0.0F, 0.0F);
         class_2403.method_9816(0.119F, 0.2F, -0.024F);
      }

   }

   private boolean doFirstPersonTransform(class_1071 stack) {
      switch(stack.method_3444()) {
      case field_9157:
      case field_9158:
         if (!LegacyEnhance.CONFIG.oldanimateOldEating.get()) {
            return true;
         }
         break;
      case field_9159:
         if (!LegacyEnhance.CONFIG.oldanimateOldSwordBlock.get()) {
            return true;
         }
         break;
      case field_9160:
         if (!LegacyEnhance.CONFIG.oldanimateOldBow.get()) {
            return true;
         }
         break;
      case field_9156:
         if (!LegacyEnhance.CONFIG.oldanimateOldModel.get()) {
            return true;
         }
      }

      class_2403.method_9816(0.58800083F, 0.36999986F, -0.77000016F);
      class_2403.method_9816(0.0F, -0.3F, 0.0F);
      class_2403.method_9800(1.5F, 1.5F, 1.5F);
      class_2403.method_9817(50.0F, 0.0F, 1.0F, 0.0F);
      class_2403.method_9817(335.0F, 0.0F, 0.0F, 1.0F);
      class_2403.method_9816(-0.9375F, -0.0625F, 0.0F);
      class_2403.method_9800(-2.0F, 2.0F, -2.0F);
      if (this.mc.method_9391().method_10240(stack)) {
         class_2403.method_9800(0.58823526F, 0.58823526F, 0.58823526F);
         class_2403.method_9817(-25.0F, 0.0F, 0.0F, 1.0F);
         class_2403.method_9817(0.0F, 1.0F, 0.0F, 0.0F);
         class_2403.method_9817(135.0F, 0.0F, 1.0F, 0.0F);
         class_2403.method_9816(0.0F, -0.25F, -0.125F);
         class_2403.method_9800(0.5F, 0.5F, 0.5F);
         return true;
      } else {
         class_2403.method_9800(0.5F, 0.5F, 0.5F);
         return false;
      }
   }

   private void doConsumeAnimation(class_1071 stack, int useCount, float partialTicks) {
      float useAmount;
      float f1;
      float f2;
      float f3;
      if (LegacyEnhance.CONFIG.oldanimateOldEating.get()) {
         useAmount = (float)useCount - partialTicks + 1.0F;
         f1 = 1.0F - useAmount / (float)stack.method_3443();
         f2 = 1.0F - f1;
         f2 = f2 * f2 * f2;
         f2 = f2 * f2 * f2;
         f2 = f2 * f2 * f2;
         f3 = 1.0F - f2;
         class_2403.method_9816(0.0F, class_837.method_2349(class_837.method_2344(useAmount / 4.0F * 3.1415927F) * 0.1F) * (float)((double)f1 > 0.2D ? 1 : 0), 0.0F);
         class_2403.method_9816(f3 * 0.6F, -f3 * 0.5F, 0.0F);
         class_2403.method_9817(f3 * 90.0F, 0.0F, 1.0F, 0.0F);
         class_2403.method_9817(f3 * 10.0F, 1.0F, 0.0F, 0.0F);
         class_2403.method_9817(f3 * 30.0F, 0.0F, 0.0F, 1.0F);
      } else {
         useAmount = (float)useCount - partialTicks + 1.0F;
         f1 = useAmount / (float)stack.method_3443();
         f2 = class_837.method_2349(class_837.method_2344(useAmount / 4.0F * 3.1415927F) * 0.1F);
         if (f1 >= 0.8F) {
            f2 = 0.0F;
         }

         class_2403.method_9816(0.0F, f2, 0.0F);
         f3 = 1.0F - (float)Math.pow((double)f1, 27.0D);
         class_2403.method_9816(f3 * 0.6F, f3 * -0.5F, f3 * 0.0F);
         class_2403.method_9817(f3 * 90.0F, 0.0F, 1.0F, 0.0F);
         class_2403.method_9817(f3 * 10.0F, 1.0F, 0.0F, 0.0F);
         class_2403.method_9817(f3 * 30.0F, 0.0F, 0.0F, 1.0F);
      }

   }

   private void doSwingTranslation(float swingProgress) {
      float swingProgress2 = class_837.method_2335(swingProgress * 3.1415927F);
      float swingProgress3 = class_837.method_2335(class_837.method_2346(swingProgress) * 3.1415927F);
      class_2403.method_9816(-swingProgress3 * 0.4F, class_837.method_2335(class_837.method_2346(swingProgress) * 3.1415927F * 2.0F) * 0.2F, -swingProgress2 * 0.2F);
   }

   private void doEquipAndSwingTransform(float equipProgress, float swingProgress) {
      class_2403.method_9816(0.56F, -0.52F - (1.0F - equipProgress) * 0.6F, -0.72F);
      class_2403.method_9817(45.0F, 0.0F, 1.0F, 0.0F);
      float swingProgress2 = class_837.method_2335(swingProgress * swingProgress * 3.1415927F);
      float swingProgress3 = class_837.method_2335(class_837.method_2346(swingProgress) * 3.1415927F);
      class_2403.method_9817(-swingProgress2 * 20.0F, 0.0F, 1.0F, 0.0F);
      class_2403.method_9817(-swingProgress3 * 20.0F, 0.0F, 0.0F, 1.0F);
      class_2403.method_9817(-swingProgress3 * 80.0F, 1.0F, 0.0F, 0.0F);
      class_2403.method_9800(0.4F, 0.4F, 0.4F);
   }

   private void doSwordBlockAnimation() {
      class_2403.method_9816(-0.5F, 0.3F, -0.1F);
      class_2403.method_9817(30.0F, 0.0F, 1.0F, 0.0F);
      class_2403.method_9817(-80.0F, 1.0F, 0.0F, 0.0F);
      class_2403.method_9817(60.0F, 0.0F, 1.0F, 0.0F);
   }

   private void doBowAnimation(class_1071 stack, int useCount, float partialTicks) {
      class_2403.method_9817(-18.0F, 0.0F, 0.0F, 1.0F);
      class_2403.method_9817(-12.0F, 0.0F, 1.0F, 0.0F);
      class_2403.method_9817(-8.0F, 1.0F, 0.0F, 0.0F);
      class_2403.method_9816(-0.9F, 0.2F, 0.0F);
      float totalPullback = (float)stack.method_3443() - ((float)useCount - partialTicks + 1.0F);
      float pullbackNorm = totalPullback / 20.0F;
      pullbackNorm = (pullbackNorm * pullbackNorm + pullbackNorm * 2.0F) / 3.0F;
      if (pullbackNorm > 1.0F) {
         pullbackNorm = 1.0F;
      }

      if (pullbackNorm > 0.1F) {
         class_2403.method_9816(0.0F, class_837.method_2335((totalPullback - 0.1F) * 1.3F) * 0.01F * (pullbackNorm - 0.1F), 0.0F);
      }

      class_2403.method_9816(0.0F, 0.0F, pullbackNorm * 0.1F);
      if (LegacyEnhance.CONFIG.oldanimateOldBow.get()) {
         class_2403.method_9817(-335.0F, 0.0F, 0.0F, 1.0F);
         class_2403.method_9817(-50.0F, 0.0F, 1.0F, 0.0F);
         class_2403.method_9816(0.0F, 0.5F, 0.0F);
      }

      float zScale = 1.0F + pullbackNorm * 0.2F;
      class_2403.method_9800(1.0F, 1.0F, zScale);
      if (LegacyEnhance.CONFIG.oldanimateOldBow.get()) {
         class_2403.method_9816(0.0F, -0.5F, 0.0F);
         class_2403.method_9817(50.0F, 0.0F, 1.0F, 0.0F);
         class_2403.method_9817(335.0F, 0.0F, 0.0F, 1.0F);
      }

   }
}
