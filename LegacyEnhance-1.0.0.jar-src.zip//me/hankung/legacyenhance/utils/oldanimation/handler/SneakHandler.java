package me.hankung.legacyenhance.utils.oldanimation.handler;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1600;
import net.minecraft.class_518;

public class SneakHandler {
   private float eyeHeight;
   private float lastEyeHeight;

   public float getEyeHeight(float partialTicks) {
      return !LegacyEnhance.CONFIG.oldanimateSmoothSneaking.get() ? this.eyeHeight : this.lastEyeHeight + (this.eyeHeight - this.lastEyeHeight) * partialTicks;
   }

   public void onTick() {
      this.lastEyeHeight = this.eyeHeight;
      class_518 player = class_1600.method_2965().field_10310;
      if (player == null) {
         this.eyeHeight = 1.62F;
      } else {
         if (player.method_2513()) {
            this.eyeHeight = 1.54F;
         } else if (!LegacyEnhance.CONFIG.oldanimateLongSneaking.get()) {
            this.eyeHeight = 1.62F;
         } else if (this.eyeHeight < 1.62F) {
            float delta = 1.62F - this.eyeHeight;
            delta = (float)((double)delta * 0.4D);
            this.eyeHeight = 1.62F - delta;
         }

      }
   }
}
