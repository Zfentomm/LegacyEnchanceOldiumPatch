package me.hankung.legacyenhance.utils.limitscan;

public interface IChunkOcclusionDataBuilder {
   void legacy$setLimitScan(boolean var1);
}
