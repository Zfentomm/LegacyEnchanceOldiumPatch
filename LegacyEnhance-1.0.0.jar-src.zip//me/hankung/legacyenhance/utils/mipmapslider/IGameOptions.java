package me.hankung.legacyenhance.utils.mipmapslider;

public interface IGameOptions {
   void legacy$onSettingsGuiClosed();
}
