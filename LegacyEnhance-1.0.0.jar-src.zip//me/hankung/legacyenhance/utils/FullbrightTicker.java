package me.hankung.legacyenhance.utils;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.server.MinecraftServer;

public class FullbrightTicker {
   public static boolean isFullbright() {
      MinecraftServer server = MinecraftServer.method_2970();
      return server != null && server.method_6640() ? false : LegacyEnhance.CONFIG.generalFullBright.get();
   }
}
