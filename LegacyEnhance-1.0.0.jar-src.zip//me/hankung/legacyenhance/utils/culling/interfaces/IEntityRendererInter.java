package me.hankung.legacyenhance.utils.culling.interfaces;

import net.minecraft.class_864;

public interface IEntityRendererInter<T extends class_864> {
   boolean shadowShouldShowName(T var1);

   void shadowRenderNameTag(T var1, double var2, double var4, double var6);
}
