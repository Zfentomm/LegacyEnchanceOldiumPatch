package me.hankung.legacyenhance.utils.culling.interfaces;

public interface IParticle {
   void setCullState(float var1);

   float getCullState();
}
