package me.hankung.legacyenhance.utils.culling.interfaces;

public interface ICullable {
   void setTimeout();

   boolean isForcedVisible();

   void setCulled(boolean var1);

   boolean isCulled();

   void setOutOfCamera(boolean var1);

   boolean isOutOfCamera();
}
