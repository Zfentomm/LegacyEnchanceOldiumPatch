package me.hankung.legacyenhance.utils.culling;

import me.hankung.legacyenhance.utils.culling.interfaces.IParticle;
import net.minecraft.class_502;
import net.minecraft.class_536;

public class ParticleCulling {
   public static class_536 camera;

   public static boolean shouldRender(class_502 particle) {
      return particle != null && (camera == null || ((IParticle)particle).getCullState() > -1.0F);
   }
}
