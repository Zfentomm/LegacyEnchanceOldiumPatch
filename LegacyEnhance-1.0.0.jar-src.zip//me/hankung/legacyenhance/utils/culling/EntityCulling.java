package me.hankung.legacyenhance.utils.culling;

import com.logisticscraft.occlusionculling.OcclusionCullingInstance;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import me.hankung.legacyenhance.utils.culling.tool.CullTask;
import me.hankung.legacyenhance.utils.culling.tool.Provider;

public class EntityCulling {
   public OcclusionCullingInstance culling;
   public CullTask cullTask;
   private Thread cullThread;
   public int renderedBlockEntities = 0;
   public int skippedBlockEntities = 0;
   public int renderedEntities = 0;
   public int skippedEntities = 0;
   public static int tracingDistance = 128;
   public Set<String> blockEntityWhitelist = new HashSet(Arrays.asList("tile.beacon"));

   public void init() {
      this.culling = new OcclusionCullingInstance(tracingDistance, new Provider());
      this.cullTask = new CullTask(this.culling, this.blockEntityWhitelist);
      this.cullThread = new Thread(this.cullTask, "CullThread");
      this.cullThread.setUncaughtExceptionHandler((thread, ex) -> {
         System.out.println("The CullingThread has crashed! Please report the following stacktrace!");
         ex.printStackTrace();
      });
      this.cullThread.start();
   }

   public void worldTick() {
      this.cullTask.requestCull = true;
   }

   public void clientTick() {
      this.cullTask.requestCull = true;
   }
}
