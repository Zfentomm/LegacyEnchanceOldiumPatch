package me.hankung.legacyenhance.utils.culling.tool;

import com.logisticscraft.occlusionculling.DataProvider;
import net.minecraft.class_1600;
import net.minecraft.class_2552;
import net.minecraft.class_478;

public class Provider implements DataProvider {
   private final class_1600 client = class_1600.method_2965();
   private class_478 world = null;

   public boolean prepareChunk(int chunkX, int chunkZ) {
      this.world = this.client.field_3803;
      return this.world != null;
   }

   public boolean isOpaqueFullCube(int x, int y, int z) {
      class_2552 pos = new class_2552(x, y, z);
      return this.world.method_8580(pos).method_9028().method_449();
   }

   public void cleanup() {
      this.world = null;
   }
}
