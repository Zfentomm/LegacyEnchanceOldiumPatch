package me.hankung.legacyenhance.utils.culling.tool;

import com.logisticscraft.occlusionculling.OcclusionCullingInstance;
import com.logisticscraft.occlusionculling.util.Vec3d;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Set;
import me.hankung.legacyenhance.LegacyEnhance;
import me.hankung.legacyenhance.utils.culling.EntityCulling;
import me.hankung.legacyenhance.utils.culling.interfaces.ICullable;
import net.minecraft.class_1600;
import net.minecraft.class_226;
import net.minecraft.class_231;
import net.minecraft.class_236;
import net.minecraft.class_2552;
import net.minecraft.class_2636;
import net.minecraft.class_864;

public class CullTask implements Runnable {
   public boolean requestCull = false;
   private final OcclusionCullingInstance culling;
   private final class_1600 client = class_1600.method_2965();
   private final int sleepDelay;
   private final int hitboxLimit;
   private final Set<String> unCullable;
   public long lastTime;
   private Vec3d lastPos;
   private Vec3d aabbMin;
   private Vec3d aabbMax;

   public CullTask(OcclusionCullingInstance culling, Set<String> unCullable) {
      this.sleepDelay = Integer.parseInt(LegacyEnhance.CONFIG.performanceEntityCullingInterval.get());
      this.hitboxLimit = 50;
      this.lastTime = 0L;
      this.lastPos = new Vec3d(0.0D, 0.0D, 0.0D);
      this.aabbMin = new Vec3d(0.0D, 0.0D, 0.0D);
      this.aabbMax = new Vec3d(0.0D, 0.0D, 0.0D);
      this.culling = culling;
      this.unCullable = unCullable;
   }

   public void run() {
      while(this.client != null) {
         try {
            Thread.sleep((long)this.sleepDelay);
            if (LegacyEnhance.CONFIG.performanceEntityCullingEnabled.get() && this.client.field_3803 != null && this.client.field_10310 != null && this.client.field_10310.field_3220 > 10 && this.client.method_9388() != null) {
               class_236 cameraMC = null;
               cameraMC = this.getCameraPos();
               if (this.requestCull || cameraMC.field_605 != this.lastPos.x || cameraMC.field_606 != this.lastPos.y || cameraMC.field_607 != this.lastPos.z) {
                  long start = System.currentTimeMillis();
                  this.requestCull = false;
                  this.lastPos.set(cameraMC.field_605, cameraMC.field_606, cameraMC.field_607);
                  Vec3d camera = this.lastPos;
                  this.culling.resetCache();
                  boolean noCulling = this.client.field_10310.method_11249() || this.client.field_3823.field_949 != 0;
                  Iterator iterator = this.client.field_3803.field_4543.iterator();

                  ICullable cullable;
                  while(iterator.hasNext()) {
                     class_226 entry;
                     try {
                        entry = (class_226)iterator.next();
                     } catch (ConcurrentModificationException | NullPointerException var14) {
                        break;
                     }

                     if (!this.unCullable.contains(entry.method_551().method_392())) {
                        cullable = (ICullable)entry;
                        if (!cullable.isForcedVisible()) {
                           if (noCulling) {
                              cullable.setCulled(false);
                           } else {
                              class_2552 pos = entry.method_8983();
                              if (pos.method_10567(cameraMC.field_605, cameraMC.field_606, cameraMC.field_607) < 4096.0D) {
                                 this.aabbMin.set((double)pos.method_10572(), (double)pos.method_10573(), (double)pos.method_10574());
                                 this.aabbMax.set((double)pos.method_10572() + 1.0D, (double)pos.method_10573() + 1.0D, (double)pos.method_10574() + 1.0D);
                                 boolean visible = this.culling.isAABBVisible(this.aabbMin, this.aabbMax, camera);
                                 cullable.setCulled(!visible);
                              }
                           }
                        }
                     }
                  }

                  cullable = null;
                  Iterator iterable = this.client.field_3803.method_3737().iterator();

                  while(iterable.hasNext()) {
                     class_864 entity;
                     try {
                        entity = (class_864)iterable.next();
                     } catch (ConcurrentModificationException | NullPointerException var13) {
                        break;
                     }

                     if (entity != null && entity instanceof ICullable) {
                        ICullable cullable = (ICullable)entity;
                        if (!cullable.isForcedVisible()) {
                           if (!noCulling && !this.isSkippableArmorstand(entity)) {
                              if (entity.method_10787().method_620(cameraMC) > (double)(EntityCulling.tracingDistance * EntityCulling.tracingDistance)) {
                                 cullable.setCulled(false);
                              } else {
                                 class_231 boundingBox = entity.method_10945();
                                 if (!(boundingBox.field_585 - boundingBox.field_582 > 50.0D) && !(boundingBox.field_586 - boundingBox.field_583 > 50.0D) && !(boundingBox.field_587 - boundingBox.field_584 > 50.0D)) {
                                    this.aabbMin.set(boundingBox.field_582, boundingBox.field_583, boundingBox.field_584);
                                    this.aabbMax.set(boundingBox.field_585, boundingBox.field_586, boundingBox.field_587);
                                    boolean visible = this.culling.isAABBVisible(this.aabbMin, this.aabbMax, camera);
                                    cullable.setCulled(!visible);
                                 } else {
                                    cullable.setCulled(false);
                                 }
                              }
                           } else {
                              cullable.setCulled(false);
                           }
                        }
                     }
                  }

                  this.lastTime = System.currentTimeMillis() - start;
               }
            }
         } catch (Exception var15) {
            var15.printStackTrace();
         }
      }

      LegacyEnhance.LOGGER.info("Shutting down culling task!");
   }

   private class_236 getCameraPos() {
      return this.client.field_3823.field_949 == 0 ? this.client.method_9388().method_10958(0.0F) : this.client.method_9388().method_10958(0.0F);
   }

   private boolean isSkippableArmorstand(class_864 entity) {
      if (LegacyEnhance.CONFIG.performanceEntityCullingCAR.get()) {
         return false;
      } else {
         return entity instanceof class_2636 && ((class_2636)entity).method_11138();
      }
   }
}
