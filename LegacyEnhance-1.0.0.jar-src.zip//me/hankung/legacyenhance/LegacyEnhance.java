package me.hankung.legacyenhance;

import io.github.axolotlclient.AxolotlClientConfig.AxolotlClientConfigManager;
import io.github.axolotlclient.AxolotlClientConfig.DefaultConfigManager;
import io.github.axolotlclient.AxolotlClientConfig.common.ConfigManager;
import io.github.axolotlclient.AxolotlClientConfig.options.OptionCategory;
import io.github.axolotlclient.AxolotlClientConfig.screen.OptionsScreenBuilder;
import me.hankung.legacyenhance.config.LegacyConfig;
import me.hankung.legacyenhance.utils.Logger;
import me.hankung.legacyenhance.utils.culling.EntityCulling;
import me.hankung.legacyenhance.utils.oldanimation.OldAnimation;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.legacyfabric.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1600;
import net.minecraft.class_1989;
import net.minecraft.class_388;

public class LegacyEnhance implements ClientModInitializer {
   public static EntityCulling entityCulling;
   public static OldAnimation oldAnimation;
   public static String NAME = "LegacyEnhance";
   public static int maxChatLength = 256;
   public static LegacyConfig CONFIG;
   public static ConfigManager configManager;
   public static Logger LOGGER = new Logger();

   public void onInitializeClient() {
      entityCulling = new EntityCulling();
      oldAnimation = new OldAnimation();
      CONFIG = new LegacyConfig();
      CONFIG.init();
      CONFIG.config.addAll(CONFIG.getCategories());
      AxolotlClientConfigManager.getInstance().registerConfig(NAME, CONFIG, configManager = new DefaultConfigManager(NAME, FabricLoader.getInstance().getConfigDir().resolve(NAME + ".json"), CONFIG.config));
      AxolotlClientConfigManager.getInstance().addIgnoredName(NAME, "x");
      AxolotlClientConfigManager.getInstance().addIgnoredName(NAME, "y");
      entityCulling.init();
      oldAnimation.init();
      ClientTickEvents.START_WORLD_TICK.register((e) -> {
         entityCulling.worldTick();
      });
      ClientTickEvents.START_CLIENT_TICK.register((e) -> {
         entityCulling.clientTick();
         oldAnimation.clientTick();
      });
      LOGGER.info("Initalized");
   }

   public static class_388 getConfigScreen(class_388 parent) {
      return new OptionsScreenBuilder(parent, (OptionCategory)(new OptionCategory(NAME, false)).addSubCategories(CONFIG.getCategories()), NAME);
   }

   public static void sendChatMessage(String message) {
      class_1600 mc = class_1600.method_2965();
      mc.field_3820.method_983().method_6690(new class_1989("§8[§d" + NAME + "§8] §f" + message));
   }
}
