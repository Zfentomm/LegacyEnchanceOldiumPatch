package me.hankung.legacyenhance.config;

import io.github.axolotlclient.AxolotlClientConfig.common.ConfigHolder;
import io.github.axolotlclient.AxolotlClientConfig.options.BooleanOption;
import io.github.axolotlclient.AxolotlClientConfig.options.EnumOption;
import io.github.axolotlclient.AxolotlClientConfig.options.Option;
import io.github.axolotlclient.AxolotlClientConfig.options.OptionCategory;
import java.util.ArrayList;
import java.util.List;

public class LegacyConfig extends ConfigHolder {
   public final OptionCategory general = new OptionCategory("General");
   public final BooleanOption generalBetterKeybind = new BooleanOption("Better Keybind Handling", true);
   public final BooleanOption generalBetterRomanNumerals = new BooleanOption("Better Roman Numerals", true);
   public final BooleanOption generalCleanView = new BooleanOption("Clean View", false);
   public final BooleanOption generalFullBright = new BooleanOption("FullBright", true);
   public final BooleanOption generalNoAchievement = new BooleanOption("No Achievement Notifications", false);
   public final BooleanOption generalNumericalEnchants = new BooleanOption("Numerical Enchantments", false);
   public final OptionCategory bugfixes = new OptionCategory("Bug Fixes");
   public final BooleanOption bugfixesAlexArmsFix = new BooleanOption("Alex Arm Position Fix", true);
   public final BooleanOption bugfixesResourceExploit = new BooleanOption("Resource Exploit Fix", true);
   public final OptionCategory betterchat = new OptionCategory("Better Chat");
   public final BooleanOption betterEnabled = new BooleanOption("enabled", true);
   public final BooleanOption betterchatCompact = new BooleanOption("Compact", true);
   public final BooleanOption betterchatTransparent = new BooleanOption("Transparent", false);
   public final BooleanOption betterchatAnimate = new BooleanOption("Smooth", true);
   public final OptionCategory oldanimate = new OptionCategory("Old Animations");
   public final BooleanOption oldanimateEnabled = new BooleanOption("enabled", true);
   public final BooleanOption oldanimateOldModel = new BooleanOption("1.7 Item Positions", true);
   public final BooleanOption oldanimateOldBow = new BooleanOption("1.7 Bow Pullback", true);
   public final BooleanOption oldanimateOldSwordBlock = new BooleanOption("1.7 Block Animation", true);
   public final BooleanOption oldanimateOldRod = new BooleanOption("1.7 Rod Position", true);
   public final BooleanOption oldanimateOldSwordBlock3rd = new BooleanOption("1.7 3rd Person Block Animation", true);
   public final BooleanOption oldanimateOldEating = new BooleanOption("1.7 Eating Animation", true);
   public final BooleanOption oldanimateOldBlockHit = new BooleanOption("1.7 Block Hit Animation", true);
   public final BooleanOption oldanimateSmoothSneaking = new BooleanOption("Smooth Sneaking", true);
   public final BooleanOption oldanimateLongSneaking = new BooleanOption("Longer Unsneak", true);
   public final BooleanOption oldanimateRedArmor = new BooleanOption("1.7 Red Armor", true);
   public final BooleanOption oldanimatePunching = new BooleanOption("Punching During Usage", true);
   public final BooleanOption oldanimateItemSwitch = new BooleanOption("Item Switching Animation", true);
   public final BooleanOption oldanimateOldTab = new BooleanOption("Tab Overlay", false);
   public final BooleanOption oldanimateOldDebugHitbox = new BooleanOption("Debug Hitbox", true);
   public final OptionCategory performance = new OptionCategory("Performance");
   public final BooleanOption performanceBatchModel = new BooleanOption("Batch Model Rendering", true);
   public final BooleanOption performanceDownscaleTexture = new BooleanOption("Downscale Texture", true);
   public final OptionCategory performanceEntityCulling = new OptionCategory("Entity Culling", true);
   public final BooleanOption performanceEntityCullingEnabled = new BooleanOption("enabled", true);
   public final EnumOption performanceEntityCullingInterval = new EnumOption("Culling Interval", new String[]{"10", "25", "50"}, "10");
   public final BooleanOption performanceEntityCullingCAR = new BooleanOption("Check Armorstand Rules", false);
   public final BooleanOption performanceEntityCullingRNTW = new BooleanOption("Render Nametags Through Walls", true);
   public final BooleanOption performanceFastWorldSwapping = new BooleanOption("Fast World Swapping", true);
   public final BooleanOption performanceLowAnimationTick = new BooleanOption("Low Animation Tick", true);
   public final BooleanOption performanceStaticParticleColor = new BooleanOption("Static Particle Color", true);
   public final List<io.github.axolotlclient.AxolotlClientConfig.common.options.OptionCategory> config = new ArrayList();
   private final List<Option<?>> options = new ArrayList();
   private final List<io.github.axolotlclient.AxolotlClientConfig.common.options.OptionCategory> categories = new ArrayList();

   public void add(Option<?> option) {
      this.options.add(option);
   }

   public void addCategory(OptionCategory cat) {
      this.categories.add(cat);
   }

   public List<io.github.axolotlclient.AxolotlClientConfig.common.options.OptionCategory> getCategories() {
      return this.categories;
   }

   public List<Option<?>> getOptions() {
      return this.options;
   }

   public void init() {
      this.categories.add(this.general);
      this.categories.add(this.bugfixes);
      this.categories.add(this.betterchat);
      this.categories.add(this.oldanimate);
      this.categories.add(this.performance);
      this.categories.forEach(io.github.axolotlclient.AxolotlClientConfig.common.options.OptionCategory::clearOptions);
      this.general.add(new io.github.axolotlclient.AxolotlClientConfig.common.options.Option[]{this.generalBetterKeybind, this.generalBetterRomanNumerals, this.generalCleanView, this.generalFullBright, this.generalNoAchievement, this.generalNumericalEnchants});
      this.bugfixes.add(new io.github.axolotlclient.AxolotlClientConfig.common.options.Option[]{this.bugfixesAlexArmsFix, this.bugfixesResourceExploit});
      this.betterchat.add(new io.github.axolotlclient.AxolotlClientConfig.common.options.Option[]{this.betterEnabled, this.betterchatCompact, this.betterchatTransparent, this.betterchatAnimate});
      this.oldanimate.add(new io.github.axolotlclient.AxolotlClientConfig.common.options.Option[]{this.oldanimateEnabled, this.oldanimateItemSwitch, this.oldanimateLongSneaking, this.oldanimateOldBlockHit, this.oldanimateOldBow, this.oldanimateOldDebugHitbox, this.oldanimateOldEating, this.oldanimateOldModel, this.oldanimateOldRod, this.oldanimateOldSwordBlock, this.oldanimateOldSwordBlock3rd, this.oldanimateOldTab, this.oldanimatePunching, this.oldanimateRedArmor, this.oldanimateSmoothSneaking});
      this.performance.add(new io.github.axolotlclient.AxolotlClientConfig.common.options.Option[]{this.performanceBatchModel, this.performanceDownscaleTexture});
      this.performanceEntityCulling.add(new io.github.axolotlclient.AxolotlClientConfig.common.options.Option[]{this.performanceEntityCullingEnabled, this.performanceEntityCullingInterval, this.performanceEntityCullingCAR, this.performanceEntityCullingRNTW});
      this.performance.add(this.performanceEntityCulling);
      this.performance.add(this.performanceFastWorldSwapping);
      this.performance.add(this.performanceLowAnimationTick);
      this.performance.add(this.performanceStaticParticleColor);
   }
}
