package me.hankung.legacyenhance.mixin.legacyenhance;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_356;
import net.minecraft.class_385;
import net.minecraft.class_388;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_385.class})
public class GameMenuScreenMixin extends class_388 {
   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void legacy$onInit(CallbackInfo ci) {
      if (!this.field_1229.method_2907()) {
         this.field_1232.add(new class_356(777, this.field_1230 / 2 + 2, this.field_1231 / 4 + 80, 98, 20, "LegacyEnhance"));
         this.field_1232.remove(3);
      }

   }

   @Inject(
      method = {"buttonClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$onButtonClicked(class_356 button, CallbackInfo ci) {
      if (button.field_1054 == 777) {
         this.field_1229.method_2928(LegacyEnhance.getConfigScreen(this.field_1229.field_3816));
         ci.cancel();
      }

   }
}
