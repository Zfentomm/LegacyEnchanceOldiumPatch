package me.hankung.legacyenhance.mixin.legacyenhance;

import net.minecraft.class_624;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_624.class})
public class TitleScreenMixin {
   @ModifyArg(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/screen/TitleScreen;drawWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)V"
)
   )
   private String fixFabricBranding(String text) {
      if (text.contains("Minecraft")) {
         text = text + "/Fabric";
      }

      return text;
   }
}
