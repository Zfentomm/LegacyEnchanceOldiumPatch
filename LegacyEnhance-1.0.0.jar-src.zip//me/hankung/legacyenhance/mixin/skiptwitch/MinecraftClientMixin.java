package me.hankung.legacyenhance.mixin.skiptwitch;

import net.minecraft.class_1600;
import net.minecraft.class_1931;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @Redirect(
      method = {"runGameLoop"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/util/TwitchStreamProvider;update()V"
)
   )
   private void legacy$skipTwitchCode1(class_1931 instance) {
   }

   @Redirect(
      method = {"runGameLoop"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/util/TwitchStreamProvider;submit()V"
)
   )
   private void legacy$skipTwitchCode2(class_1931 instance) {
   }
}
