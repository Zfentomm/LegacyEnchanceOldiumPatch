package me.hankung.legacyenhance.mixin.logspamfix;

import net.minecraft.class_1845;
import net.minecraft.class_700;
import net.minecraft.class_701;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(
   targets = {"net.minecraft.network.NetworkThreadUtils$1"}
)
public class NetworkThreadUtilsMixin {
   @Redirect(
      method = {"run"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/network/Packet;apply(Lnet/minecraft/network/listener/PacketListener;)V"
)
   )
   private void legacy$ignorePacketsFromClosedConnections(class_700 packet, class_701 listener) {
      if (listener instanceof class_1845) {
         if (((class_1845)listener).method_6841().method_7403()) {
            packet.method_1831(listener);
         }
      } else {
         packet.method_1831(listener);
      }

   }
}
