package me.hankung.legacyenhance.mixin.logspamfix;

import java.util.Map;
import net.minecraft.class_1467;
import net.minecraft.class_1468;
import net.minecraft.class_1471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1471.class})
public abstract class ScoreboardMixin {
   @Shadow
   public abstract class_1468 method_4898(String var1);

   @Inject(
      method = {"removeTeam"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$checkIfTeamIsNull(class_1468 team, CallbackInfo ci) {
      if (team == null) {
         ci.cancel();
      }

   }

   @Redirect(
      method = {"removeTeam"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/Map;remove(Ljava/lang/Object;)Ljava/lang/Object;",
   ordinal = 0
)
   )
   private <K, V> V legacy$checkIfRegisteredNameIsNull(Map<K, V> instance, K o) {
      return o != null ? instance.remove(o) : null;
   }

   @Inject(
      method = {"removeObjective"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$checkIfObjectiveIsNull(class_1467 objective, CallbackInfo ci) {
      if (objective == null) {
         ci.cancel();
      }

   }

   @Redirect(
      method = {"removeObjective"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/Map;remove(Ljava/lang/Object;)Ljava/lang/Object;",
   ordinal = 0
)
   )
   private <K, V> V legacy$checkIfNameIsNull(Map<K, V> instance, K o) {
      return o != null ? instance.remove(o) : null;
   }

   @Inject(
      method = {"addTeam"},
      at = {@At(
   value = "CONSTANT",
   args = {"stringValue=A team with the name '"}
)},
      cancellable = true
   )
   private void legacy$returnExistingTeam(String name, CallbackInfoReturnable<class_1468> cir) {
      cir.setReturnValue(this.method_4898(name));
   }

   @Inject(
      method = {"removePlayerFromTeam"},
      at = {@At(
   value = "CONSTANT",
   args = {"stringValue=Player is either on another team or not on any team. Cannot remove from team '"}
)},
      cancellable = true
   )
   private void legacy$silenceException(CallbackInfo ci) {
      ci.cancel();
   }
}
