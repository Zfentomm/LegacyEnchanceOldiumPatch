package me.hankung.legacyenhance.mixin.signchatspam;

import net.minecraft.class_1845;
import net.minecraft.class_1982;
import net.minecraft.class_518;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;

@Mixin({class_1845.class})
public class ClientPlayNetworkHandlerMixin {
   @Redirect(
      method = {"onUpdateSign"},
      slice = @Slice(
   from = @At(
   value = "CONSTANT",
   args = {"stringValue=Unable to locate sign at "},
   ordinal = 0
)
),
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/ClientPlayerEntity;sendMessage(Lnet/minecraft/text/Text;)V",
   ordinal = 0
)
   )
   private void legacy$removeDebugMessage(class_518 instance, class_1982 text) {
   }
}
