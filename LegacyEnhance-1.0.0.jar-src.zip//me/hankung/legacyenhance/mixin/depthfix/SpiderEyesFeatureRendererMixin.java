package me.hankung.legacyenhance.mixin.depthfix;

import net.minecraft.class_2403;
import net.minecraft.class_2512;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2512.class})
public class SpiderEyesFeatureRendererMixin {
   @Inject(
      method = {"render(Lnet/minecraft/entity/mob/SpiderEntity;FFFFFFF)V"},
      at = {@At("TAIL")}
   )
   private void legacy$fixDepth(CallbackInfo ci) {
      class_2403.method_9811(true);
   }
}
