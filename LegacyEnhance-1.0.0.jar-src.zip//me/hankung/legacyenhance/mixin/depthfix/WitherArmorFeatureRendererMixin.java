package me.hankung.legacyenhance.mixin.depthfix;

import net.minecraft.class_2403;
import net.minecraft.class_2516;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2516.class})
public class WitherArmorFeatureRendererMixin {
   @Inject(
      method = {"render(Lnet/minecraft/entity/boss/WitherEntity;FFFFFFF)V"},
      at = {@At("TAIL")}
   )
   private void legacy$fixDepth(CallbackInfo ci) {
      class_2403.method_9811(true);
   }
}
