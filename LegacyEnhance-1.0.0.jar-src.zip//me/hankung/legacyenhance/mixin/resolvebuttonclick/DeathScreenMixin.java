package me.hankung.legacyenhance.mixin.resolvebuttonclick;

import net.minecraft.class_364;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_364.class})
public class DeathScreenMixin {
   @Shadow
   private int field_1111;

   @Inject(
      method = {"init"},
      at = {@At("HEAD")}
   )
   private void legacy$allowClickable(CallbackInfo ci) {
      this.field_1111 = 0;
   }
}
