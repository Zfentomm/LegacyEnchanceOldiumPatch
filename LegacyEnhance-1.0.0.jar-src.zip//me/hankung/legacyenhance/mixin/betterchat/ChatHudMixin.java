package me.hankung.legacyenhance.mixin.betterchat;

import java.util.List;
import me.hankung.legacyenhance.LegacyEnhance;
import me.hankung.legacyenhance.utils.Animation;
import net.minecraft.class_1600;
import net.minecraft.class_1982;
import net.minecraft.class_2403;
import net.minecraft.class_326;
import net.minecraft.class_357;
import net.minecraft.class_389;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin({class_357.class})
public abstract class ChatHudMixin {
   @Shadow
   private boolean field_1061;
   private float percentComplete;
   private int newLines;
   private long prevMillis = System.currentTimeMillis();
   private boolean configuring;
   private float animationPercent;
   private int lineBeingDrawn;
   @Shadow
   @Final
   private class_1600 field_1057;

   @Shadow
   public abstract float method_4938();

   private void updatePercentage(long diff) {
      if (this.percentComplete < 1.0F) {
         this.percentComplete += 0.004F * (float)diff;
      }

      this.percentComplete = Animation.clamp(this.percentComplete, 0.0F, 1.0F);
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$modifyChatRendering(CallbackInfo ci) {
      if (this.configuring) {
         ci.cancel();
      } else {
         long current = System.currentTimeMillis();
         long diff = current - this.prevMillis;
         this.prevMillis = current;
         this.updatePercentage(diff);
         float t = this.percentComplete;
         this.animationPercent = Animation.clamp(1.0F - --t * t * t * t, 0.0F, 1.0F);
      }
   }

   @Inject(
      method = {"render"},
      at = {@At(
   value = "INVOKE",
   target = "Lcom/mojang/blaze3d/platform/GlStateManager;pushMatrix()V",
   ordinal = 0,
   shift = Shift.AFTER
)}
   )
   private void legacy$translate(CallbackInfo ci) {
      float y = 0.0F;
      if (LegacyEnhance.CONFIG.betterchatAnimate.get() && !this.field_1061) {
         y += (9.0F - 9.0F * this.animationPercent) * this.method_4938();
      }

      class_2403.method_9816(0.0F, y, 0.0F);
   }

   @ModifyArg(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/util/List;get(I)Ljava/lang/Object;",
   ordinal = 0
),
      index = 0
   )
   private int legacy$getLineBeingDrawn(int line) {
      this.lineBeingDrawn = line;
      return line;
   }

   @ModifyArg(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/font/TextRenderer;drawWithShadow(Ljava/lang/String;FFI)I"
),
      index = 3
   )
   private int legacy$modifyTextOpacity(int original) {
      if (LegacyEnhance.CONFIG.betterchatAnimate.get() && this.lineBeingDrawn <= this.newLines) {
         int opacity = original >> 24 & 255;
         opacity = (int)((float)opacity * this.animationPercent);
         return original & 16777215 | opacity << 24;
      } else {
         return original;
      }
   }

   @Inject(
      method = {"addMessage(Lnet/minecraft/text/Text;I)V"},
      at = {@At("HEAD")}
   )
   private void legacy$resetPercentage(CallbackInfo ci) {
      this.percentComplete = 0.0F;
   }

   @ModifyVariable(
      method = {"addMessage(Lnet/minecraft/text/Text;IIZ)V"},
      at = @At("STORE"),
      ordinal = 0
   )
   private List<class_1982> legacy$setNewLines(List<class_1982> original) {
      this.newLines = original.size() - 1;
      return original;
   }

   @ModifyArg(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   ordinal = 0,
   target = "net/minecraft/client/gui/hud/ChatHud.fill(IIIII)V"
),
      index = 4
   )
   public int legacy$customAlpha(int original) {
      return LegacyEnhance.CONFIG.betterchatTransparent.get() ? 0 : original;
   }

   @Shadow
   public abstract int method_4939();

   @Inject(
      method = {"getTextAt"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/gui/hud/ChatHud;scrolledLines:I"
)},
      cancellable = true,
      locals = LocalCapture.CAPTURE_FAILSOFT
   )
   private void legacy$stopEventsOutsideWindow(int mouseX, int mouseY, CallbackInfoReturnable<class_1982> cir, class_389 window, int i, float f, int j, int k, int l) {
      int line = k / this.field_1057.field_3814.field_1141;
      if (line >= this.method_4939()) {
         cir.setReturnValue((Object)null);
      }

   }

   @Redirect(
      method = {"removeMessage"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/hud/ChatHudLine;getId()I"
)
   )
   private int legacy$checkIfChatLineIsNull(class_326 instance) {
      return instance == null ? -1 : instance.method_836();
   }
}
