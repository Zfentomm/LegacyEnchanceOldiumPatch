package me.hankung.legacyenhance.mixin.betterchat;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_2053;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin({class_2053.class})
public class ChatMessageC2SPacketMixin {
   @ModifyConstant(
      method = {"<init>(Ljava/lang/String;)V", "read"},
      constant = {@Constant(
   intValue = 100
)}
   )
   private int legacy$useExtendedChatLength(int original) {
      return LegacyEnhance.maxChatLength;
   }
}
