package me.hankung.legacyenhance.mixin.betterchat;

import net.minecraft.class_1600;
import net.minecraft.class_1993;
import net.minecraft.class_2010;
import net.minecraft.class_359;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2010.class})
public class CloseScreenS2CPacketMixin {
   @Inject(
      method = {"apply(Lnet/minecraft/network/listener/ClientPlayPacketListener;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$noCloseMyChat(class_1993 handler, CallbackInfo ci) {
      if (class_1600.method_2965().field_3816 instanceof class_359) {
         ci.cancel();
      }

   }
}
