package me.hankung.legacyenhance.mixin.downscaletexture;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.io.InputStream;
import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1641;
import net.minecraft.class_1644;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1644.class})
public abstract class AbstractFileResourcePackMixin {
   @Shadow
   protected abstract InputStream method_5875(String var1) throws IOException;

   @Inject(
      method = {"getIcon"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$downscalePackImage(CallbackInfoReturnable<BufferedImage> cir) throws IOException {
      if (LegacyEnhance.CONFIG.performanceDownscaleTexture.get()) {
         BufferedImage image = class_1641.method_10325(this.method_5875("pack.png"));
         if (image == null) {
            cir.setReturnValue((Object)null);
         } else if (image.getWidth() <= 64 && image.getHeight() <= 64) {
            cir.setReturnValue(image);
         } else {
            BufferedImage downscaledIcon = new BufferedImage(64, 64, 2);
            Graphics graphics = downscaledIcon.getGraphics();
            graphics.drawImage(image, 0, 0, 64, 64, (ImageObserver)null);
            graphics.dispose();
            cir.setReturnValue(downscaledIcon);
         }
      }
   }
}
