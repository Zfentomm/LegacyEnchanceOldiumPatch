package me.hankung.legacyenhance.mixin.resolvenpe;

import java.util.List;
import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_485;
import net.minecraft.class_486;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({class_486.class})
public abstract class ServerListMixin {
   @Shadow
   @Final
   private List<class_485> field_1695;

   @Shadow
   public abstract void method_1278();

   @Overwrite
   public class_485 method_1274(int index) {
      try {
         return (class_485)this.field_1695.get(index);
      } catch (Exception var3) {
         LegacyEnhance.LOGGER.error("Failed to get server data.", var3);
         return null;
      }
   }

   @Overwrite
   public void method_1279(int index) {
      try {
         this.field_1695.remove(index);
      } catch (Exception var3) {
         LegacyEnhance.LOGGER.error("Failed to remove server data.", var3);
      }

   }

   @Overwrite
   public void method_1277(class_485 server) {
      try {
         this.field_1695.add(server);
      } catch (Exception var3) {
         LegacyEnhance.LOGGER.error("Failed to add server data.", var3);
      }

   }

   @Overwrite
   public void method_1275(int p_78857_1_, int p_78857_2_) {
      try {
         class_485 serverdata = this.method_1274(p_78857_1_);
         this.field_1695.set(p_78857_1_, this.method_1274(p_78857_2_));
         this.field_1695.set(p_78857_2_, serverdata);
         this.method_1278();
      } catch (Exception var4) {
         LegacyEnhance.LOGGER.error("Failed to swap servers.", var4);
      }

   }

   @Overwrite
   public void method_6852(int index, class_485 server) {
      try {
         this.field_1695.set(index, server);
      } catch (Exception var4) {
         LegacyEnhance.LOGGER.error("Failed to set server data.", var4);
      }

   }
}
