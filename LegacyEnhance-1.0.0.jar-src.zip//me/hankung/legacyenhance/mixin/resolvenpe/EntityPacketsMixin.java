package me.hankung.legacyenhance.mixin.resolvenpe;

import net.minecraft.class_1150;
import net.minecraft.class_2017;
import net.minecraft.class_2027;
import net.minecraft.class_2037;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_2027.class, class_2037.class, class_2017.class})
public class EntityPacketsMixin {
   @Inject(
      method = {"getEntity", "method_7806", "method_7850", "method_7737"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private void legacy$addNullCheck(class_1150 worldIn, CallbackInfoReturnable<class_864> cir) {
      if (worldIn == null) {
         cir.setReturnValue((Object)null);
      }

   }
}
