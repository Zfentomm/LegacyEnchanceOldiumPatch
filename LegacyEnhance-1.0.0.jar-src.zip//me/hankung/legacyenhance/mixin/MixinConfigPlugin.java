package me.hankung.legacyenhance.mixin;

import com.llamalad7.mixinextras.MixinExtrasBootstrap;
import java.util.List;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

public class MixinConfigPlugin implements IMixinConfigPlugin {
   private final boolean hasAxolotl = FabricLoader.getInstance().isModLoaded("axolotlclient");
   private final boolean hasVanillaFix = FabricLoader.getInstance().isModLoaded("legacyvanillafix");

   public void onLoad(String mixinPackage) {
      MixinExtrasBootstrap.init();
   }

   public String getRefMapperConfig() {
      return null;
   }

   public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
      if (this.hasAxolotl && mixinClassName.contains("fastworldswapping.MinecraftClientMixin")) {
         return false;
      } else {
         return !this.hasVanillaFix || !this.containsAny(mixinClassName, new String[]{"armpositionfix", "particleculling"});
      }
   }

   public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
   }

   public List<String> getMixins() {
      return null;
   }

   public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }

   public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
   }

   private boolean containsAny(String mixinClassName, String[] substrings) {
      String[] var3 = substrings;
      int var4 = substrings.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String substring = var3[var5];
         if (mixinClassName.contains(substring)) {
            return true;
         }
      }

      return false;
   }
}
