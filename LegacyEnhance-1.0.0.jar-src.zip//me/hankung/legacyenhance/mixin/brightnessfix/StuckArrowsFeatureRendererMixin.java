package me.hankung.legacyenhance.mixin.brightnessfix;

import net.minecraft.class_2495;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_2495.class})
public class StuckArrowsFeatureRendererMixin {
   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/DiffuseLighting;disable()V"
)
   )
   private void legacy$removeDisable() {
   }

   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/DiffuseLighting;enableNormally()V"
)
   )
   private void legacy$removeEnable() {
   }
}
