package me.hankung.legacyenhance.mixin.brightnessfix;

import net.minecraft.class_1150;
import net.minecraft.class_2552;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_864.class})
public class EntityMixin {
   @Redirect(
      method = {"getLightmapCoordinates"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/World;blockExists(Lnet/minecraft/util/math/BlockPos;)Z"
)
   )
   public boolean legacy$alwaysReturnTrue(class_1150 world, class_2552 pos) {
      return true;
   }
}
