package me.hankung.legacyenhance.mixin.betterkeybind;

import java.util.Iterator;
import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1600;
import net.minecraft.class_327;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @Inject(
      method = {"closeScreen"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/MouseInput;lockMouse()V"
)}
   )
   private void legacy$makeKeysReRegister(CallbackInfo ci) {
      if (LegacyEnhance.CONFIG.generalBetterKeybind.get() && !class_1600.field_6269) {
         this.legacy$updateKeyBindState();
      }

   }

   private void legacy$updateKeyBindState() {
      Iterator var1 = KeyBindingAccessor.getKEYS().iterator();

      while(var1.hasNext()) {
         class_327 keybinding = (class_327)var1.next();

         try {
            int keyCode = keybinding.method_6623();
            class_327.method_839(keyCode, keyCode < 256 && Keyboard.isKeyDown(keyCode));
         } catch (IndexOutOfBoundsException var4) {
         }
      }

   }
}
