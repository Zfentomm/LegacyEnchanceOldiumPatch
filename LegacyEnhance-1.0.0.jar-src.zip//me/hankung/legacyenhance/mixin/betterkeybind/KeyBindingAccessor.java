package me.hankung.legacyenhance.mixin.betterkeybind;

import java.util.List;
import net.minecraft.class_327;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_327.class})
public interface KeyBindingAccessor {
   @Accessor
   static List<class_327> getKEYS() {
      throw new UnsupportedOperationException("Mixin failed to inject!");
   }
}
