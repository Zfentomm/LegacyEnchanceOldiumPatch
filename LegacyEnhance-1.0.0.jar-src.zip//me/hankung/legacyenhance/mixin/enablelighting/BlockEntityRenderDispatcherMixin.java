package me.hankung.legacyenhance.mixin.enablelighting;

import net.minecraft.class_328;
import net.minecraft.class_598;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_598.class})
public class BlockEntityRenderDispatcherMixin {
   @Inject(
      method = {"renderEntity"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/World;getLight(Lnet/minecraft/util/math/BlockPos;I)I"
)}
   )
   private void legacy$enableLighting(CallbackInfo ci) {
      class_328.method_846();
   }
}
