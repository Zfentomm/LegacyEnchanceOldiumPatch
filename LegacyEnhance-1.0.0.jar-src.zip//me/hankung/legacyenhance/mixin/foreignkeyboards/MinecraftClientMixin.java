package me.hankung.legacyenhance.mixin.foreignkeyboards;

import net.minecraft.class_1600;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @Redirect(
      method = {"handleKeyInput"},
      at = @At(
   value = "INVOKE",
   target = "Lorg/lwjgl/input/Keyboard;getEventCharacter()C",
   remap = false
)
   )
   private char legacy$resolveForeignKeyboards() {
      return (char)(Keyboard.getEventCharacter() + 256);
   }
}
