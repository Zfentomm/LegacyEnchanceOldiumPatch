package me.hankung.legacyenhance.mixin.memoryleak;

import net.minecraft.class_1967;
import net.minecraft.class_1993;
import net.minecraft.class_2015;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2015.class})
public class CustomPayloadS2CPacketMixin {
   @Shadow
   private class_1967 field_11606;

   @Inject(
      method = {"apply(Lnet/minecraft/network/listener/ClientPlayPacketListener;)V"},
      at = {@At("TAIL")}
   )
   private void legacy$releaseData(class_1993 handler, CallbackInfo ci) {
      if (this.field_11606 != null) {
         this.field_11606.release();
      }

   }
}
