package me.hankung.legacyenhance.mixin.memoryleak;

import net.minecraft.class_1967;
import net.minecraft.class_2050;
import net.minecraft.class_663;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_663.class})
public class CustomPayloadC2SPacketMixin {
   @Shadow
   private class_1967 field_11702;

   @Inject(
      method = {"apply(Lnet/minecraft/network/listener/ServerPlayPacketListener;)V"},
      at = {@At("TAIL")}
   )
   private void legacy$releaseData(class_2050 handler, CallbackInfo ci) {
      if (this.field_11702 != null) {
         this.field_11702.release();
      }

   }
}
