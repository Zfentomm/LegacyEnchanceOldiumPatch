package me.hankung.legacyenhance.mixin.memoryleak;

import net.minecraft.class_1158;
import net.minecraft.class_2284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2284.class})
public class PathNodeMakerMixin {
   @Shadow
   protected class_1158 field_10235;

   @Inject(
      method = {"clear"},
      at = {@At("HEAD")}
   )
   private void legacy$cleanupBlockAccess(CallbackInfo ci) {
      this.field_10235 = null;
   }
}
