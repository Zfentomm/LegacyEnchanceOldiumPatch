package me.hankung.legacyenhance.mixin.unclosedstream;

import java.io.DataInputStream;
import java.io.IOException;
import net.minecraft.class_1205;
import net.minecraft.class_322;
import net.minecraft.class_528;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_1205.class})
public class ThreadedAnvilChunkStorageMixin {
   @Redirect(
      method = {"loadChunk"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/nbt/NbtIo;read(Ljava/io/DataInputStream;)Lnet/minecraft/nbt/NbtCompound;"
)
   )
   private class_322 legacy$closeStream(DataInputStream stream) throws IOException {
      class_322 result = class_528.method_7363(stream);
      stream.close();
      return result;
   }
}
