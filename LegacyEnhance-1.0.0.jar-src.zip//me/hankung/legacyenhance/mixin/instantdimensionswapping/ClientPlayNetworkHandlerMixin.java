package me.hankung.legacyenhance.mixin.instantdimensionswapping;

import net.minecraft.class_1845;
import net.minecraft.class_388;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_1845.class})
public class ClientPlayNetworkHandlerMixin {
   @ModifyArg(
      method = {"onGameJoin", "onPlayerRespawn"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/MinecraftClient;setScreen(Lnet/minecraft/client/gui/screen/Screen;)V"
)
   )
   private class_388 legacy$skipTerrainScreen(class_388 original) {
      return null;
   }
}
