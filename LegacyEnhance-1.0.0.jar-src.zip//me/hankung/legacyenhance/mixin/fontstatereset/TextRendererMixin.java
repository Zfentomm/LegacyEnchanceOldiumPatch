package me.hankung.legacyenhance.mixin.fontstatereset;

import net.minecraft.class_370;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_370.class})
public abstract class TextRendererMixin {
   @Shadow
   protected abstract void method_961();

   @Inject(
      method = {"draw(Ljava/lang/String;FFIZ)I"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/font/TextRenderer;drawLayer(Ljava/lang/String;FFIZ)I",
   ordinal = 0,
   shift = Shift.AFTER
)}
   )
   private void legacy$resetState(CallbackInfoReturnable<Integer> ci) {
      this.method_961();
   }
}
