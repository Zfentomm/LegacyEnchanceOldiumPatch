package me.hankung.legacyenhance.mixin.cachedisplayname;

import net.minecraft.class_1071;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1071.class})
public class ItemStackMixin {
   private String legacy$cachedDisplayName;

   @Inject(
      method = {"getCustomName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$returnCachedDisplayName(CallbackInfoReturnable<String> cir) {
      if (this.legacy$cachedDisplayName != null) {
         cir.setReturnValue(this.legacy$cachedDisplayName);
      }

   }

   @Inject(
      method = {"getCustomName"},
      at = {@At("RETURN")}
   )
   private void legacy$cacheDisplayName(CallbackInfoReturnable<String> cir) {
      this.legacy$cachedDisplayName = (String)cir.getReturnValue();
   }

   @Inject(
      method = {"setCustomName"},
      at = {@At("HEAD")}
   )
   private void legacy$resetCachedDisplayName(String displayName, CallbackInfoReturnable<class_1071> cir) {
      this.legacy$cachedDisplayName = null;
   }
}
