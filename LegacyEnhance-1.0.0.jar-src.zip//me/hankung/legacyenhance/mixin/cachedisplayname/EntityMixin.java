package me.hankung.legacyenhance.mixin.cachedisplayname;

import net.minecraft.class_1982;
import net.minecraft.class_1984;
import net.minecraft.class_1986;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_864.class})
public abstract class EntityMixin {
   private long legacy$displayNameCachedAt;
   private class_1982 legacy$cachedDisplayName;

   @Shadow
   protected abstract class_1984 method_10944();

   @Inject(
      method = {"getName"},
      at = {@At("RETURN")}
   )
   protected void legacy$cacheDisplayName(CallbackInfoReturnable<class_1982> cir) {
      this.legacy$cachedDisplayName = (class_1982)cir.getReturnValue();
      this.legacy$displayNameCachedAt = System.currentTimeMillis();
   }

   @Inject(
      method = {"getName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   protected void legacy$returnCachedDisplayName(CallbackInfoReturnable<class_1982> cir) {
      if (System.currentTimeMillis() - this.legacy$displayNameCachedAt < 50L) {
         cir.setReturnValue(this.legacy$cachedDisplayName);
      }

   }

   @Redirect(
      method = {"getName"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;getHoverEvent()Lnet/minecraft/text/HoverEvent;"
)
   )
   private class_1984 legacy$doNotGetHoverEvent(class_864 instance) {
      return null;
   }

   @Redirect(
      method = {"getName"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/text/Style;setHoverEvent(Lnet/minecraft/text/HoverEvent;)Lnet/minecraft/text/Style;"
)
   )
   private class_1986 legacy$doNotSetHoverEvent(class_1986 instance, class_1984 event) {
      return null;
   }
}
