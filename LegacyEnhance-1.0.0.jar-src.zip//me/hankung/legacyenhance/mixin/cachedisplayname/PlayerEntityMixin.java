package me.hankung.legacyenhance.mixin.cachedisplayname;

import net.minecraft.class_1600;
import net.minecraft.class_1982;
import net.minecraft.class_1984;
import net.minecraft.class_1986;
import net.minecraft.class_988;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_988.class})
public abstract class PlayerEntityMixin extends EntityMixin {
   @Inject(
      method = {"getName"},
      at = {@At("RETURN")}
   )
   private void legacy$cachePlayerDisplayName(CallbackInfoReturnable<class_1982> cir) {
      super.legacy$cacheDisplayName(cir);
   }

   @Inject(
      method = {"getName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$returnCachedPlayerDisplayName(CallbackInfoReturnable<class_1982> cir) {
      super.legacy$returnCachedDisplayName(cir);
   }

   @Redirect(
      method = {"getName"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;getHoverEvent()Lnet/minecraft/text/HoverEvent;"
)
   )
   private class_1984 legacy$onlyGetHoverEventInSinglePlayer(class_988 instance) {
      return class_1600.method_2965().method_2907() ? ((PlayerEntityMixin)instance).method_10944() : null;
   }

   @Redirect(
      method = {"getName"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/text/Style;setHoverEvent(Lnet/minecraft/text/HoverEvent;)Lnet/minecraft/text/Style;"
)
   )
   private class_1986 legacy$onlySetHoverEventInSinglePlayer(class_1986 instance, class_1984 event) {
      return class_1600.method_2965().method_2907() ? instance.method_7488(event) : null;
   }
}
