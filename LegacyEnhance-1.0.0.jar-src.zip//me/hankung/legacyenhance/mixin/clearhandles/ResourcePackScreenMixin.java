package me.hankung.legacyenhance.mixin.clearhandles;

import java.util.Iterator;
import net.minecraft.class_1600;
import net.minecraft.class_1655;
import net.minecraft.class_1657;
import net.minecraft.class_617;
import net.minecraft.class_1657.class_1659;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_617.class})
public class ResourcePackScreenMixin {
   @Inject(
      method = {"buttonClicked"},
      at = {@At(
   value = "INVOKE",
   target = "Ljava/util/Collections;reverse(Ljava/util/List;)V"
)}
   )
   private void legacy$clearHandles(CallbackInfo ci) {
      class_1657 repository = class_1600.method_2965().method_5572();
      Iterator var3 = repository.method_5905().iterator();

      while(true) {
         class_1659 entry;
         class_1655 current;
         do {
            if (!var3.hasNext()) {
               return;
            }

            entry = (class_1659)var3.next();
            current = repository.method_7039();
         } while(current != null && entry.method_5914().equals(current.method_5899()));

         entry.method_5912();
      }
   }
}
