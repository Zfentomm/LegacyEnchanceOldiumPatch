package me.hankung.legacyenhance.mixin.scoreboardtextfix;

import net.minecraft.class_371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin({class_371.class})
public class InGameHudMixin {
   @ModifyConstant(
      method = {"renderScoreboardObjective"},
      constant = {@Constant(
   intValue = 553648127
)}
   )
   private int legacy$fixTextBlending(int original) {
      return -1;
   }
}
