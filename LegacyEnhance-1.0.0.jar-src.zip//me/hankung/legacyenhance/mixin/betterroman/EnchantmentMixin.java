package me.hankung.legacyenhance.mixin.betterroman;

import me.hankung.legacyenhance.LegacyEnhance;
import me.hankung.legacyenhance.utils.RomanNumerals;
import net.minecraft.class_1127;
import net.minecraft.class_217;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1127.class})
public abstract class EnchantmentMixin {
   @Shadow
   public abstract String method_3507();

   @Inject(
      method = {"getTranslatedName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$modifyRomanNumerals(int level, CallbackInfoReturnable<String> cir) {
      String translation = class_217.method_512(this.method_3507()) + " ";
      if (LegacyEnhance.CONFIG.generalNumericalEnchants.get()) {
         cir.setReturnValue(translation + level);
      } else if (LegacyEnhance.CONFIG.generalBetterRomanNumerals.get()) {
         cir.setReturnValue(translation + RomanNumerals.toRoman(level));
      }

   }
}
