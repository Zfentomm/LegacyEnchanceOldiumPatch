package me.hankung.legacyenhance.mixin.resolverenderlayer;

import net.minecraft.class_388;
import net.minecraft.class_410;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_410.class})
public class BookEditScreenMixin extends class_388 {
   @Inject(
      method = {"render"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/screen/ingame/BookEditScreen;renderTextHoverEffect(Lnet/minecraft/text/Text;II)V"
)}
   )
   private void legacy$callSuper(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
      super.method_1025(mouseX, mouseY, partialTicks);
   }

   @Inject(
      method = {"render"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/screen/ingame/BookEditScreen;renderTextHoverEffect(Lnet/minecraft/text/Text;II)V",
   shift = Shift.AFTER
)},
      cancellable = true
   )
   private void legacy$cancelFurtherRendering(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
      ci.cancel();
   }
}
