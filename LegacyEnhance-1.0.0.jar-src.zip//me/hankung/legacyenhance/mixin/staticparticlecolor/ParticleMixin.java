package me.hankung.legacyenhance.mixin.staticparticlecolor;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_502;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_502.class})
public class ParticleMixin {
   @Redirect(
      method = {"draw"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/particle/Particle;getLightmapCoordinates(F)I"
)
   )
   private int legacy$staticParticleColor(class_502 particle, float partialTicks) {
      return LegacyEnhance.CONFIG.performanceStaticParticleColor.get() ? 15728880 : particle.method_2524(partialTicks);
   }
}
