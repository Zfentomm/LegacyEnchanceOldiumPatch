package me.hankung.legacyenhance.mixin.raceconditionfix;

import net.minecraft.class_2603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({class_2603.class})
public abstract class LazyMixin<T> {
   @Shadow
   private boolean field_11853;
   @Shadow
   private T field_11852;

   @Shadow
   protected abstract T method_10837();

   @Overwrite
   public T method_10838() {
      if (!this.field_11853) {
         synchronized(this) {
            if (!this.field_11853) {
               this.field_11852 = this.method_10837();
               this.field_11853 = true;
            }
         }
      }

      return this.field_11852;
   }
}
