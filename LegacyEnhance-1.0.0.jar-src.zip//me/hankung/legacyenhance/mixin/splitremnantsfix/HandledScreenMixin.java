package me.hankung.legacyenhance.mixin.splitremnantsfix;

import net.minecraft.class_388;
import net.minecraft.class_409;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_409.class})
public class HandledScreenMixin extends class_388 {
   @Shadow
   private int field_5716;
   @Shadow
   private int field_5718;

   @Inject(
      method = {"calculateOffset"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/item/ItemStack;copy()Lnet/minecraft/item/ItemStack;"
)},
      cancellable = true
   )
   private void legacy$fixRemnants(CallbackInfo ci) {
      if (this.field_5716 == 2) {
         this.field_5718 = this.field_1229.field_10310.field_3999.method_3150().method_3432();
         ci.cancel();
      }

   }
}
