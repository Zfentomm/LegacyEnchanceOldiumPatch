package me.hankung.legacyenhance.mixin.optimization;

import net.minecraft.class_1196;
import net.minecraft.class_1197;
import net.minecraft.class_1752;
import net.minecraft.class_2232;
import net.minecraft.class_2552;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_1196.class})
public class ChunkMixin {
   @ModifyArg(
      method = {"getBlockState"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/chunk/Chunk;method_3917(III)V",
   ordinal = 0
),
      index = 1
   )
   private int legacy$subtractOneFromY(int y) {
      return y - 1;
   }

   @Overwrite
   public class_2232 method_9154(class_2552 pos) {
      return this.getBlockState((class_1196)this, pos);
   }

   private class_2232 getBlockState(class_1196 chunk, class_2552 pos) {
      int y = pos.method_10573();
      if (y >= 0 && y >> 4 < chunk.method_3918().length) {
         class_1197 storage = chunk.method_3918()[y >> 4];
         if (storage != null) {
            return storage.method_9170(pos.method_10572() & 15, y & 15, pos.method_10574() & 15);
         }
      }

      return class_1752.field_7312.method_8633();
   }
}
