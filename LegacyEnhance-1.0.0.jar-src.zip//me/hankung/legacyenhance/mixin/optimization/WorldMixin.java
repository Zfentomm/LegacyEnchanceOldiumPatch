package me.hankung.legacyenhance.mixin.optimization;

import java.util.List;
import net.minecraft.class_1150;
import net.minecraft.class_231;
import net.minecraft.class_502;
import net.minecraft.class_864;
import net.minecraft.class_963;
import net.minecraft.class_964;
import net.minecraft.class_966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin({class_1150.class})
public class WorldMixin {
   @Inject(
      method = {"doesBoxCollide"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/World;getEntitiesIn(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Box;)Ljava/util/List;"
)},
      cancellable = true,
      locals = LocalCapture.CAPTURE_FAILSOFT
   )
   private void legacy$filterEntities(class_864 entityIn, class_231 bb, CallbackInfoReturnable<List<class_231>> cir, List<class_231> list) {
      if (entityIn instanceof class_966 || entityIn instanceof class_963 || entityIn instanceof class_964 || entityIn instanceof class_502) {
         cir.setReturnValue(list);
      }

   }
}
