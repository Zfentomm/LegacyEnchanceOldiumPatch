package me.hankung.legacyenhance.mixin.windowsimefix;

import net.minecraft.class_388;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_388.class})
public class ScreenMixin {
   @Redirect(
      method = {"handleKeyboard"},
      at = @At(
   value = "INVOKE",
   target = "Lorg/lwjgl/input/Keyboard;getEventKeyState()Z",
   remap = false
)
   )
   private boolean legacy$checkCharacter() {
      return Keyboard.getEventKey() == 0 && Keyboard.getEventCharacter() >= ' ' || Keyboard.getEventKeyState();
   }
}
