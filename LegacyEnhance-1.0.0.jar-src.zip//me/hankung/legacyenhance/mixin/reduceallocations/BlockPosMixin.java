package me.hankung.legacyenhance.mixin.reduceallocations;

import net.minecraft.class_1167;
import net.minecraft.class_1354;
import net.minecraft.class_2552;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin({class_2552.class})
public abstract class BlockPosMixin extends class_1167 {
   public BlockPosMixin(int xIn, int yIn, int zIn) {
      super(xIn, yIn, zIn);
   }

   @Overwrite
   public class_2552 method_10485() {
      return new class_2552(this.method_10572(), this.method_10573() + 1, this.method_10574());
   }

   @Overwrite
   public class_2552 method_10494(int offset) {
      return offset == 0 ? (class_2552)this : new class_2552(this.method_10572(), this.method_10573() + offset, this.method_10574());
   }

   @Overwrite
   public class_2552 method_10493() {
      return new class_2552(this.method_10572(), this.method_10573() - 1, this.method_10574());
   }

   @Overwrite
   public class_2552 method_10498(int offset) {
      return offset == 0 ? (class_2552)this : new class_2552(this.method_10572(), this.method_10573() - offset, this.method_10574());
   }

   @Overwrite
   public class_2552 method_10497() {
      return new class_2552(this.method_10572(), this.method_10573(), this.method_10574() - 1);
   }

   @Overwrite
   public class_2552 method_10501(int offset) {
      return offset == 0 ? (class_2552)this : new class_2552(this.method_10572(), this.method_10573(), this.method_10574() - offset);
   }

   @Overwrite
   public class_2552 method_10500() {
      return new class_2552(this.method_10572(), this.method_10573(), this.method_10574() + 1);
   }

   @Overwrite
   public class_2552 method_10503(int offset) {
      return offset == 0 ? (class_2552)this : new class_2552(this.method_10572(), this.method_10573(), this.method_10574() + offset);
   }

   @Overwrite
   public class_2552 method_10502() {
      return new class_2552(this.method_10572() - 1, this.method_10573(), this.method_10574());
   }

   @Overwrite
   public class_2552 method_10505(int offset) {
      return offset == 0 ? (class_2552)this : new class_2552(this.method_10572() - offset, this.method_10573(), this.method_10574());
   }

   @Overwrite
   public class_2552 method_10504() {
      return new class_2552(this.method_10572() + 1, this.method_10573(), this.method_10574());
   }

   @Overwrite
   public class_2552 method_10507(int offset) {
      return offset == 0 ? (class_2552)this : new class_2552(this.method_10572() + offset, this.method_10573(), this.method_10574());
   }

   @Overwrite
   public class_2552 method_10490(class_1354 direction) {
      return new class_2552(this.method_10572() + direction.method_4347(), this.method_10573() + direction.method_5134(), this.method_10574() + direction.method_4348());
   }
}
