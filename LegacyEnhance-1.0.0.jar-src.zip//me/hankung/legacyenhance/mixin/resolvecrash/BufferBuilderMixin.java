package me.hankung.legacyenhance.mixin.resolvecrash;

import java.nio.IntBuffer;
import net.minecraft.class_2522;
import net.minecraft.class_520;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_520.class})
public class BufferBuilderMixin {
   @Shadow
   private IntBuffer field_10643;
   @Shadow
   private class_2522 field_10653;

   @Inject(
      method = {"end"},
      at = {@At(
   value = "INVOKE",
   target = "Ljava/nio/ByteBuffer;limit(I)Ljava/nio/Buffer;"
)}
   )
   private void legacy$resetBuffer(CallbackInfo ci) {
      this.field_10643.position(0);
   }

   @Inject(
      method = {"next"},
      at = {@At("HEAD")}
   )
   private void legacy$adjustBuffer(CallbackInfo ci) {
      this.field_10643.position(this.field_10643.position() + this.field_10653.method_10342());
   }
}
