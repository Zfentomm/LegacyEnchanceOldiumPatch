package me.hankung.legacyenhance.mixin.resolvecrash;

import net.minecraft.class_322;
import net.minecraft.class_605;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_322.class})
public class NbtCompoundMixin {
   @Inject(
      method = {"put"},
      at = {@At("HEAD")}
   )
   private void legacy$failFast(String key, class_605 value, CallbackInfo ci) {
      if (value == null) {
         throw new IllegalArgumentException("Invalid null NBT value with key " + key);
      }
   }
}
