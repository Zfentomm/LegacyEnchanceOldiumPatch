package me.hankung.legacyenhance.mixin.resolvecrash;

import java.util.List;
import net.minecraft.class_1824;
import net.minecraft.class_1827;
import net.minecraft.class_1802.class_1803;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1827.class})
public class MultiplayerServerListWidgetMixin {
   @Shadow
   @Final
   private List<class_1824> field_7842;
   @Shadow
   @Final
   private class_1803 field_7843;

   @Inject(
      method = {"getEntry"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/gui/screen/multiplayer/MultiplayerServerListWidget;lanServers:Ljava/util/List;"
)},
      cancellable = true
   )
   private void legacy$resolveIndexError(int index, CallbackInfoReturnable<class_1803> cir) {
      if (index >= this.field_7842.size()) {
         cir.setReturnValue(this.field_7843);
      }

   }
}
