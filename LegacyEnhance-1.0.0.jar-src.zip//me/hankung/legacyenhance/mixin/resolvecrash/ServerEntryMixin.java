package me.hankung.legacyenhance.mixin.resolvecrash;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1825;
import net.minecraft.class_485;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_1825.class})
public abstract class ServerEntryMixin {
   @Shadow
   @Final
   private class_485 field_7834;

   @Shadow
   protected abstract void method_6789();

   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/widget/ServerEntry;checkServerIcon()V"
)
   )
   private void legacy$resolveCrash(class_1825 serverEntry) {
      try {
         this.method_6789();
      } catch (Exception var3) {
         LegacyEnhance.LOGGER.error("Failed to prepare server icon, setting to default.", var3);
         this.field_7834.method_6848((String)null);
      }

   }
}
