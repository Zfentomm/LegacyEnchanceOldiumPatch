package me.hankung.legacyenhance.mixin.resolvecrash;

import java.net.IDN;
import net.minecraft.class_484;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({class_484.class})
public class ServerAddressMixin {
   @Shadow
   @Final
   private String field_1684;

   @Overwrite
   public String method_1263() {
      try {
         return IDN.toASCII(this.field_1684);
      } catch (IllegalArgumentException var2) {
         return "";
      }
   }
}
