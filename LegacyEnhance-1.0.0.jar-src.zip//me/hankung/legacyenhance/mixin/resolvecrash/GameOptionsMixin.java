package me.hankung.legacyenhance.mixin.resolvecrash;

import net.minecraft.class_327;
import net.minecraft.class_347;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin({class_347.class})
public class GameOptionsMixin {
   @Overwrite
   public static boolean method_4931(class_327 key) {
      int keyCode = key.method_6623();
      if (keyCode != 0 && keyCode < 256) {
         return keyCode < 0 ? Mouse.isButtonDown(keyCode + 100) : Keyboard.isKeyDown(keyCode);
      } else {
         return false;
      }
   }
}
