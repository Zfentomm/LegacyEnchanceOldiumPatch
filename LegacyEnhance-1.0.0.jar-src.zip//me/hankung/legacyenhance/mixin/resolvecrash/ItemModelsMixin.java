package me.hankung.legacyenhance.mixin.resolvecrash;

import net.minecraft.class_1069;
import net.minecraft.class_1071;
import net.minecraft.class_2422;
import net.minecraft.class_2528;
import net.minecraft.class_2532;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin({class_2422.class})
public class ItemModelsMixin {
   @Shadow
   @Final
   private class_2532 field_10797;

   @Inject(
      method = {"getModel(Lnet/minecraft/item/ItemStack;)Lnet/minecraft/client/render/model/BakedModel;"},
      at = {@At(
   value = "INVOKE_ASSIGN",
   target = "Lnet/minecraft/item/ItemStack;getItem()Lnet/minecraft/item/Item;"
)},
      locals = LocalCapture.CAPTURE_FAILSOFT,
      cancellable = true
   )
   private void legacy$returnMissingModel(class_1071 stack, CallbackInfoReturnable<class_2528> cir, class_1069 item) {
      if (item == null) {
         cir.setReturnValue(this.field_10797.method_10413());
      }

   }
}
