package me.hankung.legacyenhance.mixin.banneranimationfix;

import net.minecraft.class_1150;
import net.minecraft.class_2471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_2471.class})
public class BannerBlockEntityRendererMixin {
   @Redirect(
      method = {"render(Lnet/minecraft/block/entity/BannerBlockEntity;DDDFI)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/World;getLastUpdateTime()J"
)
   )
   private long legacy$resolveOverflow(class_1150 world) {
      return world.method_4678() % 100L;
   }
}
