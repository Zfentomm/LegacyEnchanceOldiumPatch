package me.hankung.legacyenhance.mixin.armpositionfix;

import net.minecraft.class_2344;
import net.minecraft.class_570;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_570.class})
public class PlayerEntityRendererMixin {
   @Redirect(
      method = {"renderRightArm"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/render/entity/model/PlayerEntityModel;sneaking:Z",
   ordinal = 0
)
   )
   private void legacy$resetArmState(class_2344 modelPlayer, boolean value) {
      modelPlayer.field_1491 = modelPlayer.field_1484 = false;
   }
}
