package me.hankung.legacyenhance.mixin.packetspam;

import net.minecraft.class_1600;
import net.minecraft.class_347;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
   targets = {"net.minecraft.client.gui.screen.SoundsScreen$SoundButtonWidget"}
)
public class SoundsScreenMixin {
   @Redirect(
      method = {"mouseDragged(Lnet/minecraft/client/MinecraftClient;II)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/GameOptions;save()V"
)
   )
   private void legacy$cancelSaving(class_347 instance) {
   }

   @Inject(
      method = {"mouseReleased(II)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/sound/SoundManager;play(Lnet/minecraft/client/sound/SoundInstance;)V"
)}
   )
   private void legacy$save(int mouseX, int mouseY, CallbackInfo ci) {
      class_1600.method_2965().field_3823.method_873();
   }
}
