package me.hankung.legacyenhance.mixin.ingamemultiplayer;

import net.minecraft.class_356;
import net.minecraft.class_376;
import net.minecraft.class_385;
import net.minecraft.class_388;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_385.class})
public class GameMenuScreenMixin extends class_388 {
   @Inject(
      method = {"init"},
      at = {@At("TAIL")}
   )
   private void legacy$onInit(CallbackInfo ci) {
      this.field_1232.add(new class_356(333, this.field_1230 / 2 - 100, this.field_1231 / 4 + 56, 200, 20, "Multiplayer"));
   }

   @Inject(
      method = {"buttonClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$onButtonClicked(class_356 button, CallbackInfo ci) {
      if (button.field_1054 == 333) {
         this.field_1229.method_2928(new class_376(this.field_1229.field_3816));
         ci.cancel();
      }

   }
}
