package me.hankung.legacyenhance.mixin.mousebindfix;

import net.minecraft.class_1600;
import net.minecraft.class_409;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_409.class})
public class HandledScreenMixin {
   @Inject(
      method = {"mouseClicked"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$checkCloseClick(int mouseX, int mouseY, int mouseButton, CallbackInfo ci) {
      class_1600 mc = class_1600.method_2965();
      if (mouseButton - 100 == mc.field_3823.field_936.method_6623()) {
         mc.field_10310.method_9723();
         ci.cancel();
      }

   }
}
