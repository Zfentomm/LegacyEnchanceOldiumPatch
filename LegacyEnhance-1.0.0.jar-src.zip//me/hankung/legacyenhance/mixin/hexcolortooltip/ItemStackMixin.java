package me.hankung.legacyenhance.mixin.hexcolortooltip;

import net.minecraft.class_1071;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_1071.class})
public class ItemStackMixin {
   @Redirect(
      method = {"getTooltip"},
      at = @At(
   value = "INVOKE",
   target = "Ljava/lang/Integer;toHexString(I)Ljava/lang/String;"
)
   )
   private String legacy$fixHexColorString(int i) {
      return String.format("%06X", i);
   }
}
