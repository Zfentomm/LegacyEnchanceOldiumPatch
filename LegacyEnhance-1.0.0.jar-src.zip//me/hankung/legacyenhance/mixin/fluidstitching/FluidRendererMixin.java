package me.hankung.legacyenhance.mixin.fluidstitching;

import net.minecraft.class_2431;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin({class_2431.class})
public class FluidRendererMixin {
   @ModifyConstant(
      method = {"render"},
      constant = {@Constant(
   floatValue = 0.001F
)}
   )
   private float legacy$fixFluidStitching(float original) {
      return 0.0F;
   }
}
