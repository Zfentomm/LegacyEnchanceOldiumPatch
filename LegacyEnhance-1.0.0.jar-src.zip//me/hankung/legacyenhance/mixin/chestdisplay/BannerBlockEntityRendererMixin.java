package me.hankung.legacyenhance.mixin.chestdisplay;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1600;
import net.minecraft.class_1653;
import net.minecraft.class_2225;
import net.minecraft.class_2471;
import net.minecraft.class_2519;
import net.minecraft.class_2674;
import net.minecraft.class_2225.class_2226;
import net.minecraft.class_2471.class_2472;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin({class_2471.class})
public class BannerBlockEntityRendererMixin {
   @Shadow
   @Final
   private static Map<String, class_2472> field_11009;
   @Shadow
   @Final
   private static class_1653 field_11010;

   @Overwrite
   private class_1653 method_10097(class_2225 banner) {
      String texture = banner.method_8966();
      if (texture.isEmpty()) {
         return null;
      } else {
         class_2472 timedTexture = (class_2472)field_11009.get(texture);
         if (timedTexture == null) {
            if (field_11009.size() >= 256 && !this.legacy$freeCacheSlot()) {
               return field_11010;
            }

            List<class_2226> patternList = banner.method_8961();
            List<class_2674> colorList = banner.method_8964();
            List<String> patternPath = Lists.newArrayList();
            Iterator var7 = patternList.iterator();

            while(var7.hasNext()) {
               class_2226 pattern = (class_2226)var7.next();
               patternPath.add("textures/entity/banner/" + pattern.method_8968() + ".png");
            }

            timedTexture = new class_2472();
            timedTexture.field_11013 = new class_1653(texture);
            class_1600.method_2965().method_5570().method_5849(timedTexture.field_11013, new class_2519(field_11010, patternPath, colorList));
            field_11009.put(texture, timedTexture);
         }

         timedTexture.field_11012 = System.currentTimeMillis();
         return timedTexture.field_11013;
      }
   }

   @Unique
   private boolean legacy$freeCacheSlot() {
      long start = System.currentTimeMillis();
      Iterator iterator = field_11009.keySet().iterator();

      class_2472 timedTexture;
      do {
         if (!iterator.hasNext()) {
            return field_11009.size() < 256;
         }

         String next = (String)iterator.next();
         timedTexture = (class_2472)field_11009.get(next);
      } while(start - timedTexture.field_11012 <= 5000L);

      class_1600.method_2965().method_5570().method_7015(timedTexture.field_11013);
      iterator.remove();
      return true;
   }
}
