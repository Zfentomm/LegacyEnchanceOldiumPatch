package me.hankung.legacyenhance.mixin.resetunicodefont;

import net.minecraft.class_380;
import net.minecraft.class_388;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_380.class})
public class LanguageOptionsScreenMixin extends class_388 {
   public void method_1030() {
      this.field_1229.field_3820.method_983().method_4934();
   }
}
