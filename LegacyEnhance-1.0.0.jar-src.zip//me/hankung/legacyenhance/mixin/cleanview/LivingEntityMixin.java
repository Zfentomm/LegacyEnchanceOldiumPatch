package me.hankung.legacyenhance.mixin.cleanview;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1600;
import net.minecraft.class_1699;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1699.class})
public class LivingEntityMixin {
   @Inject(
      method = {"tickStatusEffects"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/world/World;addParticle(Lnet/minecraft/client/particle/ParticleType;DDDDDD[I)V"
)},
      cancellable = true
   )
   private void legacy$cleanView(CallbackInfo ci) {
      if (LegacyEnhance.CONFIG.generalCleanView.get() && this == class_1600.method_2965().field_10310) {
         ci.cancel();
      }

   }
}
