package me.hankung.legacyenhance.mixin.adjustheightfix;

import net.minecraft.class_869;
import net.minecraft.class_988;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_869.class})
public class ExperienceOrbEntityMixin {
   @Redirect(
      method = {"tick"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;getEyeHeight()F"
)
   )
   private float legacy$lowerHeight(class_988 playerEntity) {
      return (float)((double)playerEntity.method_2544() / 2.0D);
   }
}
