package me.hankung.legacyenhance.mixin.openpackfolderfix;

import java.awt.Desktop;
import java.io.IOException;
import net.minecraft.class_1600;
import net.minecraft.class_617;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_617.class})
public class ResourcePackScreenMixin {
   @Inject(
      method = {"buttonClicked"},
      at = {@At(
   value = "INVOKE",
   target = "Ljava/lang/Runtime;getRuntime()Ljava/lang/Runtime;",
   ordinal = 1,
   shift = Shift.BEFORE
)},
      cancellable = true
   )
   private void legacy$fixFolderOpening(CallbackInfo ci) throws IOException {
      Desktop.getDesktop().open(class_1600.method_2965().method_5572().method_5907());
      ci.cancel();
   }
}
