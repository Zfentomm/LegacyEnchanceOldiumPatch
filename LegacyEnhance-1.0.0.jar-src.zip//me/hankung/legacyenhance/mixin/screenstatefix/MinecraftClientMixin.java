package me.hankung.legacyenhance.mixin.screenstatefix;

import net.minecraft.class_1600;
import org.apache.commons.lang3.SystemUtils;
import org.lwjgl.opengl.Display;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @Shadow
   private boolean field_3775;

   @Inject(
      method = {"toggleFullscreen"},
      at = {@At(
   value = "INVOKE",
   target = "Lorg/lwjgl/opengl/Display;setFullscreen(Z)V",
   remap = false
)}
   )
   private void legacy$resolveScreenState(CallbackInfo ci) {
      if (!this.field_3775 && SystemUtils.IS_OS_WINDOWS) {
         Display.setResizable(false);
         Display.setResizable(true);
      }

   }
}
