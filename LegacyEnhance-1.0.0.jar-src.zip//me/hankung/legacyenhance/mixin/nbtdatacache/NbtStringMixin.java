package me.hankung.legacyenhance.mixin.nbtdatacache;

import net.minecraft.class_579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_579.class})
public class NbtStringMixin {
   @Shadow
   private String field_2141;
   @Unique
   private String legacy$dataCache;

   @Inject(
      method = {"read"},
      at = {@At("HEAD")}
   )
   private void legacy$emptyDataCache(CallbackInfo ci) {
      this.legacy$dataCache = null;
   }

   @Overwrite
   public String toString() {
      if (this.legacy$dataCache == null) {
         this.legacy$dataCache = "\"" + this.field_2141.replace("\"", "\\\"") + "\"";
      }

      return this.legacy$dataCache;
   }
}
