package me.hankung.legacyenhance.mixin.uselessanimations;

import net.minecraft.class_519;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_519.class})
public class OtherClientPlayerEntityMixin {
   @Inject(
      method = {"tickMovement"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/OtherClientPlayerEntity;tickHandSwing()V",
   shift = Shift.AFTER
)},
      cancellable = true
   )
   private void legacy$removeUselessAnimations(CallbackInfo ci) {
      ci.cancel();
   }
}
