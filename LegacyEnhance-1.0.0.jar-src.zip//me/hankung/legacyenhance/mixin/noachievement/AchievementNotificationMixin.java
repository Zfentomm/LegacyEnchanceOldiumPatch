package me.hankung.legacyenhance.mixin.noachievement;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_399;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_399.class})
public class AchievementNotificationMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$cancelRendering(CallbackInfo ci) {
      if (LegacyEnhance.CONFIG.generalNoAchievement.get()) {
         ci.cancel();
      }

   }
}
