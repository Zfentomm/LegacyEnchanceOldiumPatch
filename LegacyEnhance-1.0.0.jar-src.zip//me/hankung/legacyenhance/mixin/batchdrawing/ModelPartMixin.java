package me.hankung.legacyenhance.mixin.batchdrawing;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_2520;
import net.minecraft.class_467;
import net.minecraft.class_533;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_467.class})
public class ModelPartMixin {
   @Shadow
   private boolean field_1611;
   private boolean legacy$compiledState;

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void legacy$resetCompiled(float j, CallbackInfo ci) {
      if (this.legacy$compiledState != LegacyEnhance.CONFIG.performanceBatchModel.get()) {
         this.field_1611 = false;
      }

   }

   @Inject(
      method = {"compileList"},
      at = {@At(
   value = "INVOKE_ASSIGN",
   target = "Lnet/minecraft/client/render/Tessellator;getBuffer()Lnet/minecraft/client/render/BufferBuilder;"
)}
   )
   private void legacy$beginRendering(CallbackInfo ci) {
      this.legacy$compiledState = LegacyEnhance.CONFIG.performanceBatchModel.get();
      if (LegacyEnhance.CONFIG.performanceBatchModel.get()) {
         class_533.method_9926().method_9928().method_9737(7, class_2520.field_11204);
      }

   }

   @Inject(
      method = {"compileList"},
      at = {@At(
   value = "INVOKE",
   target = "Lorg/lwjgl/opengl/GL11;glEndList()V",
   remap = false
)}
   )
   private void legacy$draw(CallbackInfo ci) {
      if (LegacyEnhance.CONFIG.performanceBatchModel.get()) {
         class_533.method_9926().method_9927();
      }

   }
}
