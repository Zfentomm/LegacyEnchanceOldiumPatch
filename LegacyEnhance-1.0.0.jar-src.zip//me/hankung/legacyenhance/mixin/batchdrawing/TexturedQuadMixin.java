package me.hankung.legacyenhance.mixin.batchdrawing;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_447;
import net.minecraft.class_520;
import net.minecraft.class_533;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_447.class})
public class TexturedQuadMixin {
   @Unique
   private boolean legacy$drawOnSelf;

   @Redirect(
      method = {"draw"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/BufferBuilder;begin(ILnet/minecraft/client/render/VertexFormat;)V"
)
   )
   private void legacy$beginDraw(class_520 renderer, int glMode, class_2522 format) {
      this.legacy$drawOnSelf = !((BufferBuilderAccessor)renderer).isDrawing();
      if (this.legacy$drawOnSelf || !LegacyEnhance.CONFIG.performanceBatchModel.get()) {
         renderer.method_9737(glMode, class_2520.field_11211);
      }

   }

   @Redirect(
      method = {"draw"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/Tessellator;draw()V"
)
   )
   private void legacy$endDraw(class_533 tessellator) {
      if (this.legacy$drawOnSelf || !LegacyEnhance.CONFIG.performanceBatchModel.get()) {
         tessellator.method_9927();
      }

   }
}
