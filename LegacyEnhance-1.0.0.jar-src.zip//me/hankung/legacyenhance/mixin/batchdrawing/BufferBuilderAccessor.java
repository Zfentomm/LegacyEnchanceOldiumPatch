package me.hankung.legacyenhance.mixin.batchdrawing;

import net.minecraft.class_520;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_520.class})
public interface BufferBuilderAccessor {
   @Accessor("building")
   boolean isDrawing();
}
