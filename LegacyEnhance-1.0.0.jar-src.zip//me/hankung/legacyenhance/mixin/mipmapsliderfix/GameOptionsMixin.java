package me.hankung.legacyenhance.mixin.mipmapsliderfix;

import com.google.common.util.concurrent.ListenableFuture;
import me.hankung.legacyenhance.utils.mipmapslider.IGameOptions;
import net.minecraft.class_1600;
import net.minecraft.class_347;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_347.class})
public class GameOptionsMixin implements IGameOptions {
   @Shadow
   protected class_1600 field_946;
   private boolean legacy$needsResourceRefresh;

   public void legacy$onSettingsGuiClosed() {
      if (this.legacy$needsResourceRefresh) {
         this.field_946.method_9379();
         this.legacy$needsResourceRefresh = false;
      }

   }

   @Redirect(
      method = {"setValue"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/MinecraftClient;reloadResourcesConcurrently()Lcom/google/common/util/concurrent/ListenableFuture;"
)
   )
   private ListenableFuture<Object> legacy$reloadResourcesConcurrently(class_1600 instance) {
      this.legacy$needsResourceRefresh = true;
      return null;
   }
}
