package me.hankung.legacyenhance.mixin.mipmapsliderfix;

import me.hankung.legacyenhance.utils.mipmapslider.IGameOptions;
import net.minecraft.class_388;
import net.minecraft.class_398;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_398.class})
public class VideoOptionsScreenMixin extends class_388 {
   public void method_1030() {
      super.method_1030();
      ((IGameOptions)this.field_1229.field_3823).legacy$onSettingsGuiClosed();
   }
}
