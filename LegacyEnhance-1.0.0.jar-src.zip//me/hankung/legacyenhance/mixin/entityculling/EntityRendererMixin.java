package me.hankung.legacyenhance.mixin.entityculling;

import me.hankung.legacyenhance.utils.culling.interfaces.IEntityRendererInter;
import net.minecraft.class_551;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({class_551.class})
public abstract class EntityRendererMixin<T extends class_864> implements IEntityRendererInter<T> {
   public boolean shadowShouldShowName(T entity) {
      return this.method_10211(entity);
   }

   public void shadowRenderNameTag(T p_renderName_1_, double p_renderName_2_, double d1, double d2) {
      this.method_10208(p_renderName_1_, p_renderName_2_, d1, d2);
   }

   @Shadow
   protected abstract void method_10208(T var1, double var2, double var4, double var6);

   @Shadow
   protected abstract boolean method_10211(T var1);
}
