package me.hankung.legacyenhance.mixin.entityculling;

import java.util.List;
import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_2294;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_2294.class})
public class DebugHudMixin {
   public DebugHudMixin() {
      LegacyEnhance.entityCulling.clientTick();
   }

   @Inject(
      method = {"getLeftText"},
      at = {@At("RETURN")}
   )
   public List<String> legacy$getLeftText(CallbackInfoReturnable<List<String>> cir) {
      List<String> list = (List)cir.getReturnValue();
      list.add("[Culling] Last pass: " + LegacyEnhance.entityCulling.cullTask.lastTime + "ms");
      list.add("[Culling] Rendered Block Entities: " + LegacyEnhance.entityCulling.renderedBlockEntities + " Skipped: " + LegacyEnhance.entityCulling.skippedBlockEntities);
      list.add("[Culling] Rendered Entities: " + LegacyEnhance.entityCulling.renderedEntities + " Skipped: " + LegacyEnhance.entityCulling.skippedEntities);
      LegacyEnhance.entityCulling.renderedBlockEntities = 0;
      LegacyEnhance.entityCulling.skippedBlockEntities = 0;
      LegacyEnhance.entityCulling.renderedEntities = 0;
      LegacyEnhance.entityCulling.skippedEntities = 0;
      return list;
   }
}
