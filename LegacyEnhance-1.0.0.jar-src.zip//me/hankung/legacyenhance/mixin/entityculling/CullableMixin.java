package me.hankung.legacyenhance.mixin.entityculling;

import me.hankung.legacyenhance.LegacyEnhance;
import me.hankung.legacyenhance.utils.culling.interfaces.ICullable;
import net.minecraft.class_226;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_864.class, class_226.class})
public class CullableMixin implements ICullable {
   private long lasttime = 0L;
   private boolean culled = false;
   private boolean outOfCamera = false;

   public void setTimeout() {
      this.lasttime = System.currentTimeMillis() + 1000L;
   }

   public boolean isForcedVisible() {
      return this.lasttime > System.currentTimeMillis();
   }

   public void setCulled(boolean value) {
      this.culled = value;
      if (!value) {
         this.setTimeout();
      }

   }

   public boolean isCulled() {
      return !LegacyEnhance.CONFIG.performanceEntityCullingEnabled.get() ? false : this.culled;
   }

   public void setOutOfCamera(boolean value) {
      this.outOfCamera = value;
   }

   public boolean isOutOfCamera() {
      return !LegacyEnhance.CONFIG.performanceEntityCullingEnabled.get() ? false : this.outOfCamera;
   }
}
