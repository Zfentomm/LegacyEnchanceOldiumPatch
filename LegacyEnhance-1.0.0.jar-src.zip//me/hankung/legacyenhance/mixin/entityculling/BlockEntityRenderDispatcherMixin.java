package me.hankung.legacyenhance.mixin.entityculling;

import me.hankung.legacyenhance.LegacyEnhance;
import me.hankung.legacyenhance.utils.culling.interfaces.ICullable;
import net.minecraft.class_226;
import net.minecraft.class_598;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_598.class})
public class BlockEntityRenderDispatcherMixin {
   @Inject(
      method = {"renderEntity(Lnet/minecraft/block/entity/BlockEntity;DDDFI)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void legacy$onRenderEntity(class_226 blockEntity, double x, double y, double z, float tickDelta, int destroyProgress, CallbackInfo ci) {
      if (!((ICullable)blockEntity).isForcedVisible() && ((ICullable)blockEntity).isCulled()) {
         ++LegacyEnhance.entityCulling.skippedBlockEntities;
         ci.cancel();
      } else {
         ++LegacyEnhance.entityCulling.renderedBlockEntities;
      }
   }
}
