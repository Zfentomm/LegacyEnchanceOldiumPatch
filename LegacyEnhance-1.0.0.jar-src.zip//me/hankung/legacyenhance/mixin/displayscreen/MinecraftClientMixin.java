package me.hankung.legacyenhance.mixin.displayscreen;

import net.minecraft.class_1600;
import net.minecraft.class_1814;
import net.minecraft.class_388;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @ModifyArg(
      method = {"startIntegratedServer"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/MinecraftClient;setScreen(Lnet/minecraft/client/gui/screen/Screen;)V"
)
   )
   private class_388 legacy$displayWorkingScreen(class_388 original) {
      return new class_1814();
   }
}
