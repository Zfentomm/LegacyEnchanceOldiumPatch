package me.hankung.legacyenhance.mixin.mousedelayfix;

import net.minecraft.class_1150;
import net.minecraft.class_1699;
import net.minecraft.class_236;
import net.minecraft.class_518;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1699.class})
public abstract class LivingEntityMixin extends class_864 {
   public LivingEntityMixin(class_1150 worldIn) {
      super(worldIn);
   }

   @Inject(
      method = {"getRotationVector"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$mouseDelayFix(float partialTicks, CallbackInfoReturnable<class_236> cir) {
      if ((class_1699)this instanceof class_518) {
         cir.setReturnValue(super.method_6146(partialTicks));
      }

   }
}
