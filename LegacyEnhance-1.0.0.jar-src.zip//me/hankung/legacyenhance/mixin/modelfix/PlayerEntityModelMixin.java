package me.hankung.legacyenhance.mixin.modelfix;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_2344;
import net.minecraft.class_440;
import net.minecraft.class_467;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin({class_2344.class})
public class PlayerEntityModelMixin extends class_440 {
   @Shadow
   private boolean field_10567;

   @ModifyConstant(
      method = {"<init>"},
      constant = {@Constant(
   floatValue = 2.5F
)}
   )
   private float legacy$fixAlexArmHeight(float original) {
      return LegacyEnhance.CONFIG.bugfixesAlexArmsFix.get() ? 2.0F : original;
   }

   @Overwrite
   public void method_9636(float scale) {
      if (this.field_10567) {
         class_467 var10000 = this.field_10556;
         var10000.field_1597 += 0.5F;
         this.field_10556.method_1195(scale);
         var10000 = this.field_10556;
         var10000.field_1599 -= 0.5F;
      } else {
         this.field_10556.method_1195(scale);
      }

   }
}
