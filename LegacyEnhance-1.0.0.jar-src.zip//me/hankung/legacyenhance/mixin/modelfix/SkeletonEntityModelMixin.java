package me.hankung.legacyenhance.mixin.modelfix;

import net.minecraft.class_440;
import net.minecraft.class_454;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_454.class})
public class SkeletonEntityModelMixin extends class_440 {
   public void method_9636(float scale) {
      ++this.field_10556.field_1597;
      this.field_10556.method_1195(scale);
      --this.field_10556.field_1597;
   }
}
