package me.hankung.legacyenhance.mixin.sprintparticlefix;

import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_864.class})
public class EntityMixin {
   @Shadow
   public boolean field_3197;

   @Inject(
      method = {"attemptSprintingParticles"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$checkGroundState(CallbackInfo ci) {
      if (!this.field_3197) {
         ci.cancel();
      }

   }
}
