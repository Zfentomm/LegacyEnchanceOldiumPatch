package me.hankung.legacyenhance.mixin.fastersearching;

import java.io.File;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1657.class_1659;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_1657.class})
public interface ResourcePackLoaderAccessor {
   @Invoker
   List<File> invokeGetResourcePacks();

   @Accessor
   void setAvailableResourcePacks(List<class_1659> var1);
}
