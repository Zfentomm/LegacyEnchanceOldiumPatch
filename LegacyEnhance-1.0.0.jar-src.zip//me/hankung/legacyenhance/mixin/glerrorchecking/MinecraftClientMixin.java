package me.hankung.legacyenhance.mixin.glerrorchecking;

import net.minecraft.class_1600;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @Shadow
   private boolean field_10301;

   @Inject(
      method = {"initializeGame"},
      at = {@At("TAIL")}
   )
   private void legacy$disableGlErrorChecking(CallbackInfo ci) {
      this.field_10301 = false;
   }
}
