package me.hankung.legacyenhance.mixin.savesettings;

import net.minecraft.class_383;
import net.minecraft.class_388;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_383.class})
public class SettingsScreenMixin extends class_388 {
   public void method_1030() {
      this.field_1229.field_3823.method_873();
   }
}
