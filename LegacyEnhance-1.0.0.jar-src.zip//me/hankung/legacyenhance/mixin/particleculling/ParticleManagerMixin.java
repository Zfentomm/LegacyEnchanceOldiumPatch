package me.hankung.legacyenhance.mixin.particleculling;

import me.hankung.legacyenhance.utils.culling.ParticleCulling;
import me.hankung.legacyenhance.utils.culling.interfaces.IParticle;
import net.minecraft.class_502;
import net.minecraft.class_503;
import net.minecraft.class_520;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;

@Mixin({class_503.class})
public class ParticleManagerMixin {
   @Redirect(
      method = {"renderParticles"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/particle/Particle;draw(Lnet/minecraft/client/render/BufferBuilder;Lnet/minecraft/entity/Entity;FFFFFF)V"
)
   )
   private void legacy$cullParticles(class_502 instance, class_520 worldRendererIn, class_864 entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ) {
      if (ParticleCulling.shouldRender(instance)) {
         instance.method_1283(worldRendererIn, entityIn, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
      }

   }

   @ModifyVariable(
      method = {"updateLayer(Ljava/util/List;)V"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/particle/ParticleManager;tickParticle(Lnet/minecraft/client/particle/Particle;)V",
   shift = Shift.AFTER
)
   )
   private class_502 legacy$checkIfCulled(class_502 particle) {
      if (ParticleCulling.camera != null) {
         ((IParticle)particle).setCullState(ParticleCulling.camera.method_1491(particle.method_10945()) ? 1.0F : -1.0F);
      }

      return particle;
   }
}
