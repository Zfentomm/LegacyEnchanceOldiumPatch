package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_2494;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_2494.class})
public class ArmorFeatureRendererMixin {
   @Inject(
      method = {"combineTextures"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void legacy$applyRedArmor(CallbackInfoReturnable<Boolean> cir) {
      if (LegacyEnhance.CONFIG.oldanimateRedArmor.get()) {
         cir.setReturnValue(true);
      }

   }
}
