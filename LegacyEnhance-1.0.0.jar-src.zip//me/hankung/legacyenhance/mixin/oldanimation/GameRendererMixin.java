package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1600;
import net.minecraft.class_524;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_524.class})
public class GameRendererMixin {
   @Shadow
   private class_1600 field_1860;
   @Unique
   private float partialTicks;

   @Inject(
      method = {"transformCamera"},
      at = {@At("HEAD")}
   )
   public void legacy$transformCamera(float partialTicks, CallbackInfo ci) {
      this.partialTicks = partialTicks;
   }

   @ModifyVariable(
      method = {"transformCamera"},
      at = @At(
   value = "STORE",
   ordinal = 0
),
      ordinal = 1
   )
   public float legacy$modifyEyeHeight_transformCamera(float eyeHeight) {
      return this.field_1860.method_9388() != this.field_1860.field_10310 ? eyeHeight : LegacyEnhance.oldAnimation.sneakHandler.getEyeHeight(this.partialTicks);
   }

   @Redirect(
      method = {"renderDebugCrosshair"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;getEyeHeight()F"
)
   )
   public float legacy$modifyEyeHeight_renderDebugCrosshair(class_864 entity) {
      return this.field_1860.method_9388() != this.field_1860.field_10310 ? entity.method_2544() : LegacyEnhance.oldAnimation.sneakHandler.getEyeHeight(this.partialTicks);
   }
}
