package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1071;
import net.minecraft.class_1600;
import net.minecraft.class_518;
import net.minecraft.class_529;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_529.class})
public class HeldItemRendererMixin {
   @Shadow
   private class_1071 field_1877;
   @Shadow
   private float field_1879;
   @Shadow
   private float field_1878;
   @Shadow
   private int field_1882;

   @Inject(
      method = {"renderArmHoldingItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void legacy$renderArmHoldingItem(float partialTicks, CallbackInfo ci) {
      if (this.field_1877 != null) {
         class_529 $this = (class_529)this;
         float equipProgress = this.field_1879 + (this.field_1878 - this.field_1879) * partialTicks;
         if (LegacyEnhance.oldAnimation.animationHandler.renderItemInFirstPerson($this, this.field_1877, equipProgress, partialTicks)) {
            ci.cancel();
         }
      }

   }

   @ModifyArg(
      method = {"updateHeldItems"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/util/math/MathHelper;clamp(FFF)F"
),
      index = 0
   )
   private float legacy$handleItemSwitch(float original) {
      class_518 entityplayer = class_1600.method_2965().field_10310;
      class_1071 itemstack = entityplayer.field_3999.method_3142();
      return LegacyEnhance.CONFIG.oldanimateItemSwitch.get() && this.field_1882 == entityplayer.field_3999.field_3966 && class_1071.method_11311(this.field_1877, itemstack) ? 1.0F - this.field_1878 : original;
   }
}
