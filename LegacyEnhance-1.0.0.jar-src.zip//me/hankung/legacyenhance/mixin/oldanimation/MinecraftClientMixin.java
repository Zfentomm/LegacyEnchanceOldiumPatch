package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1096;
import net.minecraft.class_1099;
import net.minecraft.class_1600;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1600.class})
public class MinecraftClientMixin {
   @Inject(
      method = {"doUse"},
      at = {@At("HEAD")}
   )
   public void legacy$doUse(CallbackInfo ci) {
      class_1600 mc = class_1600.method_2965();
      if (LegacyEnhance.CONFIG.oldanimatePunching.get() && mc.field_3800.method_9668() && mc.field_10310.method_2640() != null && (mc.field_10310.method_2640().method_3444() != class_1099.field_9156 || mc.field_10310.method_2640().method_3421() instanceof class_1096)) {
         mc.field_3800.method_1238();
      }

   }
}
