package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_440;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin({class_440.class})
public class BiPedModelMixin {
   @ModifyConstant(
      method = {"setAngles"},
      constant = {@Constant(
   floatValue = -0.5235988F
)}
   )
   private float legacy$cancelRotation(float original) {
      return LegacyEnhance.CONFIG.oldanimateOldSwordBlock3rd.get() ? 0.0F : original;
   }
}
