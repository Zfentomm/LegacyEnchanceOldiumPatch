package me.hankung.legacyenhance.mixin.oldanimation;

import net.minecraft.class_1065;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1065.class})
public interface FoodItemAccessor {
   @Accessor("alwaysEdible")
   boolean getAlwaysEdible();
}
