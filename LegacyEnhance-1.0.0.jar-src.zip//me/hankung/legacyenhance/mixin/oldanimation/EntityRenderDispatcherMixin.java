package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_231;
import net.minecraft.class_530;
import net.minecraft.class_533;
import net.minecraft.class_550;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_550.class})
public class EntityRenderDispatcherMixin {
   @Redirect(
      method = {"renderHitbox"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/WorldRenderer;drawBox(Lnet/minecraft/util/math/Box;IIII)V",
   ordinal = 1
)
   )
   private void legacy$cancelRenderGlobalCall(class_231 boundingBox, int red, int green, int blue, int alpha) {
      if (!LegacyEnhance.CONFIG.oldanimateOldDebugHitbox.get()) {
         class_530.method_9896(boundingBox, red, green, blue, alpha);
      }

   }

   @Redirect(
      method = {"renderHitbox"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/Tessellator;draw()V"
)
   )
   private void legacy$cancelTessellatorDraw(class_533 tessellator) {
      if (!LegacyEnhance.CONFIG.oldanimateOldDebugHitbox.get()) {
         tessellator.method_9927();
      } else {
         tessellator.method_9928().method_9752();
      }

   }
}
