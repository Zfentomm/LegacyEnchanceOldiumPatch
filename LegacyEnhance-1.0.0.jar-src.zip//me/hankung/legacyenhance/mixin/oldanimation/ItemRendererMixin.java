package me.hankung.legacyenhance.mixin.oldanimation;

import me.hankung.legacyenhance.LegacyEnhance;
import net.minecraft.class_1071;
import net.minecraft.class_1099;
import net.minecraft.class_1699;
import net.minecraft.class_2528;
import net.minecraft.class_560;
import net.minecraft.class_988;
import net.minecraft.class_2462.class_2464;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_560.class})
public class ItemRendererMixin {
   @Unique
   private class_1699 lastEntityToRenderFor = null;

   @Inject(
      method = {"renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/model/json/ModelTransformation$Mode;)V"},
      at = {@At("HEAD")}
   )
   public void legacy$renderItem(class_1071 stack, class_1699 entityToRenderFor, class_2464 cameraTransformType, CallbackInfo ci) {
      this.lastEntityToRenderFor = entityToRenderFor;
   }

   @Inject(
      method = {"renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/BakedModel;Lnet/minecraft/client/render/model/json/ModelTransformation$Mode;)V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/item/ItemRenderer;renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/BakedModel;)V"
)}
   )
   public void legacy$renderItem(class_1071 stack, class_2528 model, class_2464 cameraTransformType, CallbackInfo ci) {
      if (cameraTransformType == class_2464.field_10993 && this.lastEntityToRenderFor instanceof class_988) {
         class_988 p = (class_988)this.lastEntityToRenderFor;
         class_1071 heldStack = p.method_2640();
         if (heldStack != null && p.method_3192() > 0 && heldStack.method_3444() == class_1099.field_9159) {
            LegacyEnhance.oldAnimation.animationHandler.doSwordBlock3rdPersonTransform();
         }
      }

   }
}
