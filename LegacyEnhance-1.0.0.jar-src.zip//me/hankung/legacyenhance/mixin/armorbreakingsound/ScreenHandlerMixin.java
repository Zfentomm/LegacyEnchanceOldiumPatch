package me.hankung.legacyenhance.mixin.armorbreakingsound;

import net.minecraft.class_1002;
import net.minecraft.class_1018;
import net.minecraft.class_1026;
import net.minecraft.class_1028;
import net.minecraft.class_1071;
import net.minecraft.class_1600;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1002.class})
public class ScreenHandlerMixin {
   @Inject(
      method = {"setStackInSlot"},
      at = {@At("HEAD")}
   )
   private void legacy$playArmorBreakingSound(int slotID, class_1071 stack, CallbackInfo ci) {
      if (class_1600.method_2965().field_3803.field_4532 && stack == null) {
         class_1002 screenHandler = (class_1002)this;
         if (slotID >= 5 && slotID <= 8 && screenHandler instanceof class_1018) {
            class_1026 slot = screenHandler.method_3251(slotID);
            if (slot != null) {
               class_1071 slotStack = slot.method_3299();
               if (slotStack != null && slotStack.method_3421() instanceof class_1028 && slotStack.method_3439() > slotStack.method_3441() - 2) {
                  class_1600.method_2965().field_10310.method_4441("random.break", 1.0F, 1.0F);
               }
            }
         }

      }
   }
}
