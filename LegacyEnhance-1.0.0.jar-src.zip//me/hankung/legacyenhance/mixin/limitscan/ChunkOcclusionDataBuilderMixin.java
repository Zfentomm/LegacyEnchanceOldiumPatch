package me.hankung.legacyenhance.mixin.limitscan;

import java.util.Queue;
import java.util.Set;
import me.hankung.legacyenhance.utils.limitscan.IChunkOcclusionDataBuilder;
import net.minecraft.class_1354;
import net.minecraft.class_2484;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin({class_2484.class})
public class ChunkOcclusionDataBuilderMixin implements IChunkOcclusionDataBuilder {
   @Unique
   private boolean legacy$limitScan;

   @Inject(
      method = {"getOpenFaces(I)Ljava/util/Set;"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/chunk/ChunkOcclusionDataBuilder;addEdgeFaces(ILjava/util/Set;)V",
   shift = Shift.AFTER
)},
      locals = LocalCapture.CAPTURE_FAILSOFT,
      cancellable = true
   )
   private void legacy$checkLimitScan(int enumfacing, CallbackInfoReturnable<Set<class_1354>> cir, Set<class_1354> set, Queue<Integer> queue, int i) {
      if (this.legacy$limitScan && set.size() > 1) {
         cir.setReturnValue(set);
      }

   }

   public void legacy$setLimitScan(boolean limitScan) {
      this.legacy$limitScan = limitScan;
   }
}
