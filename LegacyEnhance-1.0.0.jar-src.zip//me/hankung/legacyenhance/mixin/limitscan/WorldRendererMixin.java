package me.hankung.legacyenhance.mixin.limitscan;

import me.hankung.legacyenhance.utils.limitscan.IChunkOcclusionDataBuilder;
import net.minecraft.class_2484;
import net.minecraft.class_530;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({class_530.class})
public class WorldRendererMixin {
   @ModifyVariable(
      method = {"getOpenChunkFaces"},
      name = {"visgraph"},
      at = @At(
   value = "STORE",
   ordinal = 0
)
   )
   private class_2484 legacy$setLimitScan(class_2484 visgraph) {
      ((IChunkOcclusionDataBuilder)visgraph).legacy$setLimitScan(true);
      return visgraph;
   }
}
